# -*- coding: utf-8 -*-
# -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-

import LineNeo
from LineNeo.lib.curve.ttypes import *
from datetime import datetime, date, time
from bs4 import BeautifulSoup
import time, random, sys, re, os, six, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, urllib2, wikipedia,tempfile,glob,shutil,unicodedata,goslate
from gtts import gTTS
import requests
from urllib import urlopen
import urllib2
import urllib3
import tempfile
import html5lib
import ast,io
import google

cl = LineNeo.LINE()
cl.login(token="EongdMUsDhnyz0Ihx8cd.bFt/SJvuk3tVrtJBv+kGVq.ARXZGm+VjEaofPVy2FA58NMOSLVjv+Yl6vhwY/F4jiY=")
cl.loginResult()

k1 = LineNeo.LINE()
k1.login(token="EoHcwyLKeew1jO02jyba.KvOD7oCa8IUHCEww4ms8/G.qH4nHVN77XArHtJV38zJh65iJBJX3+CIghMQG31llAI=")
k1.loginResult()

k2 = LineNeo.LINE()
k2.login(token="EoNeuk54wmoX4bFLvCH8.OHIXKvawFmQ0574decyMEa.7UdIhSe8BW56OG3n7dvAWfgWBLh0ayIvHkOJzd71z/o=")
k2.loginResult()

k3 = LineNeo.LINE()
k3.login(token="Eo93hjUe2PciiMIEfhW1.Hff9nf47TQ/qZ17zP0WFeq.paxZGIkJ7koVnX70BnCaWfF0Zwg3+X62thXBYmfb2e4=")
k3.loginResult()

k4 = LineNeo.LINE()
k4.login(token="EoShtyvwFuCeUiJwhNNe.W4b1Gm7fD2pDiM0+LaWlJG.sh05+a5TTRLjxe8h0w1aq7HftoB4cEWfN6y5WT01iTI=")
k4.loginResult()

k5 = LineNeo.LINE()
k5.login(token="EoAEQWcEUGRFD5hwKuY4.MR2xc24bTNw8s50tifFJva.rhyyLNZRa47gshl7AxouFh6QSi7MVzPDqyMU9eMaO4k=")
k5.loginResult()

k6 = LineNeo. LINE()
k6.login(token="EoLeJmchE4teJulDPFtc.aD5Jt3gYWgatfSpdu+HnFa.eKSzVcTMRIquSybYdZvdGLKpT9xDoyorKu5gN8sBU6Q=")
k6.loginResult()

k7 = LineNeo. LINE()
k7.login(token="Eosa7a5GpGoVZ4kOrhV1.Glf2xd679UfWUBPDj+V8Gq.Seh9peEtyPp/ckZ/trAMDuFapu812gwn1hiMr6KB8u4=")
k7.loginResult()

k8 = LineNeo. LINE()
k8.login(token="Eo7zhxuaSOoUkxs99ou4.ZMan74DxGF5ujvSgW2m+ja.7Xz4vho8Goh3kuGgLe47Wi38Cu36UGMAEvm17+IMQ7s=")
k8.loginResult()

k9 = LineNeo. LINE()
k9.login(token="EoUl31iBaI7GwOxZGaf1.YyCZ690sOcohBv2ESoxKCq.T8RkF1eLesS0Ad/NvqkJZc2VHxaD+wsX61DxqfYCxyE=")
k9.loginResult()

k10 = LineNeo. LINE()
k10.login(token="Eo923pwJHpwp7Lx4rh59.Mutckvoe3zLv5fW+B53yIq.A9i9LiuZmrhg9Fi0dYDwD+JpfwguHIQHcO/RxFW4a8s=")
k10.loginResult()

#backup siri
siri = LineNeo.LINE()
siri.login(token="Eo31rEveh0alRKEt4H03.m+FfoX8+xkbrh11nriX2KW.WhA//dKqJB7FtdYHp6Fsa0f3YiU29Rvob3As6JjEguQ=")
siri.loginResult()

print ("[SELFBOT_READY_RUNING]")
reload(sys)
sys.setdefaultencoding('utf-8')
helpMessage ="""⌯ꏍ⌯༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻⌯ꏍ⌯
⌯ꏍ⌯ COMMENT STANDART ⌯ꏍ⌯
----------------------------------------------
⌯ꏍ⌯ Me
⌯ꏍ⌯ Id
⌯ꏍ⌯ Mid
⌯ꏍ⌯ Gid
⌯ꏍ⌯ Help
⌯ꏍ⌯ Help2
⌯ꏍ⌯ Gift
⌯ꏍ⌯ Gift1-3
⌯ꏍ⌯ Up
⌯ꏍ⌯ Ginfo
⌯ꏍ⌯ Gourl
⌯ꏍ⌯ Link on
⌯ꏍ⌯ Link off
⌯ꏍ⌯ Creator
⌯ꏍ⌯ Gcreator
⌯ꏍ⌯ Mid mid
⌯ꏍ⌯ Rgroups
⌯ꏍ⌯ Mygroups
⌯ꏍ⌯ G creator
⌯ꏍ⌯ Kick: (mid)
⌯ꏍ⌯ Invite: (mid)
⌯ꏍ⌯ Tl: (text)
⌯ꏍ⌯ Cc: (text)
⌯ꏍ⌯ Message: (text)
⌯ꏍ⌯ Comment: (text)
⌯ꏍ⌯ Myname: (text)
⌯ꏍ⌯ Group name: (text)
⌯ꏍ⌯ Mypmcast: (text)
⌯ꏍ⌯ Mygroupcast: (text)
⌯ꏍ⌯ Update welcome: (text)
⌯ꏍ⌯ Check welcome message
⌯ꏍ⌯ Invite gcreator
⌯ꏍ⌯ Restart
⌯ꏍ⌯ Tagall
⌯ꏍ⌯ Tagmem
⌯ꏍ⌯ Lurk
⌯ꏍ⌯ Lurkers
⌯ꏍ⌯ Point
⌯ꏍ⌯ Readpoint
⌯ꏍ⌯ Quotes
⌯ꏍ⌯ Time
⌯ꏍ⌯ Jam
⌯ꏍ⌯ Run time
⌯ꏍ⌯ Bye bye
⌯ꏍ⌯ All contact
⌯ꏍ⌯ Turn off bots
⌯ꏍ⌯ Cancel invites
----------------------------------------------
⌯ꏍ⌯   PROMOT / DEMODE   ⌯ꏍ⌯
----------------------------------------------
⌯ꏍ⌯ Add staff:on
⌯ꏍ⌯ Expel staff:on
⌯ꏍ⌯ Staff:on @
⌯ꏍ⌯ Expel:on @
⌯ꏍ⌯ Staff list
⌯ꏍ⌯ Notag:on/off
⌯ꏍ⌯ Auto chat:on/off
⌯ꏍ⌯ Tag respon:on/off
⌯ꏍ⌯ Talk ban:on/off
⌯ꏍ⌯ Check @
⌯ꏍ⌯ Copy @
⌯ꏍ⌯ Spam @
⌯ꏍ⌯ Group pic
⌯ꏍ⌯ Cover @
⌯ꏍ⌯ Pp @
⌯ꏍ⌯ Mid @
⌯ꏍ⌯ Steal bio @
⌯ꏍ⌯ Steal group pict
⌯ꏍ⌯ Ban
⌯ꏍ⌯ Unban
⌯ꏍ⌯ Ban:on @
⌯ꏍ⌯ Unban:on @
⌯ꏍ⌯ Block @
⌯ꏍ⌯ Blacklist
⌯ꏍ⌯ Blocklist
⌯ꏍ⌯ Ban:repeat
⌯ꏍ⌯ Unban:repeat
⌯ꏍ⌯ Clear ban
⌯ꏍ⌯ Unbanall
⌯ꏍ⌯ Repeat:off
⌯ꏍ⌯ Clear ban
⌯ꏍ⌯ Cbanlist
⌯ꏍ⌯ Ban cek
⌯ꏍ⌯ Setlastpoint
⌯ꏍ⌯Viewlastseen
-----------------------------------------------
⌯ꏍ⌯    COMMENT BOT      
-----------------------------------------------
⌯ꏍ⌯ Bot help
⌯ꏍ⌯ Say (text)
⌯ꏍ⌯ Bot1/2/3
⌯ꏍ⌯ Bot saya (text)
⌯ꏍ⌯ #welcome
⌯ꏍ⌯ All join
⌯ꏍ⌯ A/B/C
⌯ꏍ⌯ Bye
⌯ꏍ⌯ Bot1 gift
⌯ꏍ⌯ All gift
⌯ꏍ⌯ All gid
⌯ꏍ⌯ Ping
⌯ꏍ⌯ Bot mid
⌯ꏍ⌯ Bot1 creator
⌯ꏍ⌯ Neo qron
⌯ꏍ⌯ Neo qroff
⌯ꏍ⌯ Bot1 glist
⌯ꏍ⌯ Respon
⌯ꏍ⌯ Spam (text)
⌯ꏍ⌯ Pmcast: (text)
⌯ꏍ⌯ Groupcast: (text)
⌯ꏍ⌯ Broadcast: (text)
⌯ꏍ⌯ Bot1 pmcast: (text)
⌯ꏍ⌯ Bot1 groupcast: (text)
⌯ꏍ⌯ Bot1 tl: (text)
⌯ꏍ⌯ Bot1 invite: (mid)
⌯ꏍ⌯ Bot1 update name: (text)
⌯ꏍ⌯ Neo cancel invites
⌯ꏍ⌯ Bot1 rgroups
⌯ꏍ⌯ Bot1 copy @
⌯ꏍ⌯ Bot gurl
⌯ꏍ⌯ Bot1 gourl
⌯ꏍ⌯ Neo1 tagall
-----------------------------------------------
⌯ꏍ⌯ COMMENT KICK  & PROTECT
-----------------------------------------------
⌯ꏍ⌯ Nk: @
⌯ꏍ⌯ Fuck @
⌯ꏍ⌯ Kick @
⌯ꏍ⌯ Tkick @
⌯ꏍ⌯ Kill
⌯ꏍ⌯ Cleanse 
⌯ꏍ⌯ Mayhem
⌯ꏍ⌯ Neo1 kick @
⌯ꏍ⌯ Kill ban
⌯ꏍ⌯ Lurk:on/off
⌯ꏍ⌯ Notag:on\off
⌯ꏍ⌯ Invite:on/off
⌯ꏍ⌯ Backup:on/off
⌯ꏍ⌯ Comment:on/off
⌯ꏍ⌯ Clock:on/off
⌯ꏍ⌯ Share:on/off
⌯ꏍ⌯ Auto chat:on\off
⌯ꏍ⌯ Respon tag:on\off
⌯ꏍ⌯ Contact:on/off
⌯ꏍ⌯ Auto like:on/off
⌯ꏍ⌯ Auto join:on/off
⌯ꏍ⌯ Auto leave:on/off
⌯ꏍ⌯ Auto add:on/off
⌯ꏍ⌯ Welcome:on/off
⌯ꏍ⌯ Gcancel:on/off
⌯ꏍ⌯ Protect:on/off
⌯ꏍ⌯ Autokick:on/off
⌯ꏍ⌯ Protect qr:on/off
⌯ꏍ⌯ Blockinvite:on/off
⌯ꏍ⌯ Protect name:on/off
⌯ꏍ⌯ Protect invite:on/off
⌯ꏍ⌯ Auto purge:on/off
⌯ꏍ⌯ All protect:on/off
-------------------------------------------------
⌯ꏍ⌯✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈
⌯ꏍ⌯༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"""

KAC = [cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
KAC2 = [k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]

mid = cl.getProfile().mid
Amid = k1.getProfile().mid
Bmid = k2.getProfile().mid
Cmid = k3.getProfile().mid
Dmid = k4.getProfile().mid
Emid = k5.getProfile().mid
Fmid = k6.getProfile().mid
Gmid = k7.getProfile().mid
Hmid = k8.getProfile().mid
Imid = k9.getProfile().mid
Jmid = k10.getProfile().mid
siri = siri.getProfile().mid

Bots = [mid, Amid, Bmid, Cmid, Dmid, Emid, Fmid, Gmid, Hmid, Imid, Jmid, siri]

protectname = {
    "pro_name":{},
}
creator = ["u05f4feb235542b74ef4538db57f2a0bd"]
admin = ["u05f4feb235542b74ef4538db57f2a0bd"]

wait = {
    'contact':False,
    'autoJoin':False,
    'autoCancel':{"on":True, "members":1},
    'leaveRoom':False,
    'timeline':False,
    'autoAdd':False,
    "lang":"JP",
    "comment":"Auto like by: ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻",
    "commentOn":False,
    "likeOn":False,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cName":"􀰂􀰂􀰂􀰂􀰂􀠁􀠁􀠁",
    "akaInvite":{},
    "blacklist":{},
    "whitelist":{},
    "rblacklist":{},
    "rdblacklist":{},
    'pname':{},
    'cloning':True,
    "wblacklist":False,
    "dblacklist":False,
    "qr":False,
    "AutoKick":False,
    "Backup":False,
    "blockInviteOn":False,
    "protectCancel":False,
    "lurkingOn":False,
    "welcomeOn":False,
    "purgeOn":False,
    "protectionOn":False,
    "message":"Thanks for add me ask friends. selfbot by ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™ 🙏🙏THANKS 🙏🙏",
    'welmsg':'WELCOME TO:',
    'leavemsg':'SAMPAI JIMPA LAGI',
    "talkblacklist":{},
    "talkwblacklist":False,
    "talkdblacklist":False,
    'detectMention':False,
    'kickMention':False,
    "talkban":False,
    "untalk":False,
    'siri':False,
    'atjointicket':False,
    }
wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }
wait3 = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }
settings = {
    "simiSimi":{},
    'chatbot':{},
    }
sider = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }

setTime = {}
setTime = wait2['setTime']
setTime = sider['setTime']
start = datetime.now()
mulai = datetime.now()

#with open('settingan.json', 'r') as fp:
#    periksa = json.load(fp)
#with open('sider.json', 'r') as fp:
#    sider = json.load(fp)
with open('st2__b.json', 'r') as fp:
	protectname = json.load(fp)

profile = cl.getProfile().mid
contact = cl.getProfile()
mybackup = cl.getProfile()
mybackup.displayName = contact.displayName
mybackup.statusMessage = contact.statusMessage
mybackup.pictureStatus = contact.pictureStatus
contact = k1.getProfile()
backup1 = k1.getProfile()
backup1.displayName = contact.displayName
backup1.statusMessage = contact.statusMessage
backup1.pictureStatus = contact.pictureStatus
contact = k2.getProfile()
backup2 = k2.getProfile()
backup2.displayName = contact.displayName
backup2.statusMessage = contact.statusMessage
backup2.pictureStatus = contact.pictureStatus
contact = k3.getProfile()
backup3 = k3.getProfile()
backup3.displayName = contact.displayName
backup3.statusMessage = contact.statusMessage
backup3.pictureStatus = contact.pictureStatus
contact = k4.getProfile()
backup4 = k4.getProfile()
backup4.displayName = contact.displayName
backup4.statusMessage = contact.statusMessage
backup4.pictureStatus = contact.pictureStatus
contact = k5.getProfile()
backup5 = k5.getProfile()
backup5.displayName = contact.displayName
backup5.statusMessage = contact.statusMessage
backup5.pictureStatus = contact.pictureStatus
contact = k6.getProfile()
backup6 = k6.getProfile()
backup6.displayName = contact.displayName
backup6.statusMessage = contact.statusMessage
backup6.pictureStatus = contact.pictureStatus
contact = k7.getProfile()
backup7 = k7.getProfile()
backup7.displayName = contact.displayName
backup7.statusMessage = contact.statusMessage
backup7.pictureStatus = contact.pictureStatus
contact = k8.getProfile()
backup8 = k8.getProfile()
backup8.displayName = contact.displayName
backup8.statusMessage = contact.statusMessage
backup8.pictureStatus = contact.pictureStatus
contact = k9.getProfile()
backup9 = k9.getProfile()
backup9.displayName = contact.displayName
backup9.statusMessage = contact.statusMessage
backup9.pictureStatus = contact.pictureStatus
contact = k10.getProfile()
backup10 = k10.getProfile()
backup10.displayName = contact.displayName
backup10.statusMessage = contact.statusMessage
backup10.pictureStatus = contact.pictureStatus

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False
#---------------------------------------------------------------------------------------
def yt(query):
    with requests.session() as s:
         isi = []
         if query == "":
             query = "S1B tanysyz"   
         s.headers['user-agent'] = 'Mozilla/5.0'
         url    = 'http://www.youtube.com/results'
         params = {'search_query': query}
         r    = s.get(url, params=params)
         soup = BeautulSoup(r.content, 'html5lib')
         for a in soup.select('.yt-lockup-title > a[title]'):
            if '&list=' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=', '')
                    isi += ['youtu.be' + b]
         return isi

agent = {'User-Agent' : "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)"}

def translate(to_translate, to_language="auto", language="auto"):
    base_link = "http://translate.google.com/m?hl=%s&sl=%s&q=%s"
    if (six.PY2):
        link = base_link % (to_language, language, urllib.pathname2url(to_translate))
        request = urllib2.Request(link, headers=agent)
        page = urllib2.urlopen(request).read()
    else:
        link = base_link % (to_language, language, urllib.parse.quote(to_translate))
        request = urllib.request.Request(link, headers=agent)
        page = urllib.request.urlopen(request).read().decode("utf-8")
    expr = r'class="t0">(.*?)<'
    result = re.findall(expr, page)
    if (len(result) == 0):
        return (result[0])
    return(result[0])
    
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid="
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content

def _images_getItem_(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid="
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content

def sendImage(self, to_, path):
      M = Message(to=to_,contentType = 1)
      M.contentMetadata = None
      M.contentPreview = None
      M_id = self.Talk.client.sendMessage(0,M).id
      files = {
         'file': open(path, 'rb'),
      }
      params = {
         'name': 'media',
         'oid': M_id,
         'size': len(open(path, 'rb').read()),
         'type': 'image',
         'ver': '1.0',
      }
      data = {
         'params': json.dumps(params)
      }
      r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
      if r.status_code != 201:
         raise Exception('Upload image failure.')
      return True

def upload_tempimage(client):
     '''
         Upload a picture of a kitten. We don't ship one, so get creative!
     '''
     config = {
         'album': album,
         'name':  'bot auto upload',
         'title': 'bot auto upload',
         'description': 'bot auto upload'
     }

     print("Uploading image... ")
     image = client.upload_from_path(image_path, config=config, anon=False)
     print("Done")
     print()

#Getting all links with the help of '_images_get_next_image'
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      #Append all the links in the list named 'Links'
            time.sleep(0.1)        #Timer could be used to slow down the request for image downloads
            page = page[end_content:]
    return items

#--------------------------------------------------------------------------
def sendAudio(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentType = 3).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': objectId,
            'size': len(open(path, 'rb').read()),
            'type': 'audio',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.server.postContent(self.server.LINE_OBS_DOMAIN + '/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload audio failure.')
        return True
            
def sendAudio(self, to, path):
       M = Message()
       M.text = None
       M.to = to
       M.contentMetadata = None
       M.contentPreview = None
       M.contentType = 3
       M_id = self._client.sendMessage(0,M).id
       files = {
             'file': open(path,  'rb'),
       }

def sendAudio(self, to_, path):
        M = Message(to=to_,contentType = 3)
        M.contentMetadata = None
        M.contentPreview = None
        M_id = self.Talk.client.sendMessage(0,M).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': M_id,
            'size': len(open(path, 'rb').read()),
            'type': 'audio',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload image failure.')
        return True

def sendAudioWithURL(self, to, url):
        path = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))
        r = requests.get(url, stream=True)
        if r.status_code == 200:
         with open(path, 'w') as f:
            shutil.copyfileobj(r.raw, f)
        else:
         raise Exception('Download audio failure.')
        try:
         self.sendAudio(to_, path)
        except Exception as e:
         raise e

def sendAudioWithURL(self, to, url):
        path = self.downloadFileWithURL(url)
        try:
            self.sendAudio(to_, path)
        except Exception as e:
            raise Exception(e)

#---------------------------------------------------------------------------
def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib,request    #urllib library for Extracting web pages
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def mention(to,nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nama:
     akh = akh + 2
     aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
     strt = strt + 6
     akh = akh + 4
     bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print("[COMMENT TAG ALL]")
    try:
      cl.sendMessage(msg)
    except Exception as error:
       print(error)

def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print ("[Command] Tag All")
    try:
       cl.sendMessage(msg)
    except Exception as error:
       print (error)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return 'Jam %02d Menit %02d Detik %02d' % (hours, mins, secs)
    
def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.to, mes,from_ = to
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def sendContact(self, to, mid):
      msg = Message()
      msg.to = to
      msg.text = None
      msg.contentType = 13
      msg.contentMetadata = {'mid': mid}
      return self.Talk.client.sendMessage(0, msg)
#-------------------------------------------------------------------------------
def NOTIFIED_READ_MESSAGE(op):
    print
    try:
        if op.param1 in wait2['readPoint']:
            Name = cl.getContact(op.param2).displayName
            if Name in wait2['readMember'][op.param1]:
                pass
            else:
                wait2['readMember'][op.param1] += "\n・" + Name + datetime.now().strftime('%H:%M:%S]')
                wait2['ROM'][op.param1][op.param2] = "・" + Name + " ツ"
        else:
            pass
    except:
        pass

def RECEIVE_MESSAGE(op):
    msg = op.message
    try:
        if msg.contentType == 0:
            try:
                if msg.to in wait2['readPoint']:
                    if msg.from_ in wait2["ROM"][msg.to]:
                        del wait2["ROM"][msg.to][msg.from_]
                else:
                    pass
            except:
                pass
        else:
            pass
    except KeyboardInterrupt:
       sys.exit(0)
    except Exception as error:
        print
        print ("[RECEIVED TEXT MESSAGES]")
        return

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return 'Jam %02d Menit %02d 😉' % (hours, mins, secs)
#--------------------------------------------------------------------------------

def bot(op):
    global notag
    global changeimage
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))

        if op.type == 17:
          if wait["welcomeOn"] == True:
            if op.param2 in admin:
                return
                ginfo = cl.getGroup(op.param1)
                cl.sendText(op.param1, cl.getContact(op.param2).displayName + "\n\n✅▶" + wait["welmsg"]+ "\n✍" + str(ginfo.name) + "\nDETIME: " + datetime.today().strftime(' [%H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")
                print ("[MEMBER JOIN TO GROUPS]")

        if op.type == 15:
          if wait["welcomeOn"] == True:
            if op.param2 in admin:
                return
                cl.sendText(op.param1 + "\n\n✅▶" + wait["leavemsg"]+ "\n✍" + str(ginfo.name) + "\nDETIME: " + datetime.today().strftime(' [%H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")
                print ("[MEMBER LEAVE FROM GROUP]")
#---------------------------------------------------------------------------------
        if op.type == 11:
            if op.param2 not in Bots and admin:
              if wait["qr"] == True:
                try:
                    klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                    G = random.choice(klist).getGroup(op.param1)
                    G.preventJoinByTicket = True
                    random.choice(klist).updateGroup(G)
                    G.sendText(op.param1,"Hi " + random.choice(klist).getContact(op.param2).displayName + "\nDon't Play Code QR Link Please . . . (~_~;)")
                except Exception as e:
                    print (e)

        if op.type == 11:
            if op.param2 not in Bots and admin:
            	if wait["siri"] == True:
            		try:
            			klist=[ki,kk,kc,ks,kt]
            			kicker = random.choice(klist)
            			G = kicker.getGroup(op.param1)
            			G.preventJoinByTicket = False
            			kicker.updateGroup(G)
            			invsend = 0
            			Ticket = kicker.reissueGroupTicket(op.param1)
            			siri.acceptGroupInvitationByTicket(op.param1,Ticket)
            			time.sleep(0.2)
            			X = kicker.getGroup(op.param1)
            			X.preventJoinByTicket = True
            			siri.kickoutFromGroup(op.param1,[op.param2])
 #           			kicker.kickoutFromGroup(op.param1,[op.param2])
            			siri.leaveGroup(op.param1)
            			kicker.updateGroup(X)
            		except Exception, e:
            			print e

            if op.param2 not in Bots and admin:
              if wait["protectionOn"] == True:
                 try:
                     klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                     G = random.choice(klist).getGroup(op.param1)
                     G.preventJoinByTicket = True
                     random.choice(klist).updateGroup(G)
                     random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                     wait["blacklist"][op.param2] = True
                     random.choice(klist).kickoutFromGroup(op.param1,[op.param3])
                     wait["blacklist"][op.param3] = True
                     G.preventJoinByTicket = True
                     random.choice(klist).updateGroup(G)
                 except Exception as e:
                           print (e)
#-----------------------------------------------------------------------
        if op.type == 11:
            if op.param3 == "1":
              if op.param1 in protectname:
                  group = cl.getGroup(op.param1)
              try:
                  group.name = wait["pro_name"][op.param1]
                  cl.updateGroup(group)
                  cl.sendText(op.param1, "Groupname protect now")
                  wait["blacklist"][op.param2] = True
                  f=codecs.open('st2__b.json','w','utf-8')
                  json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
              except Exception as e:
                    print (e)
                    pass

#----------------------------------------------------------------------------
        if op.type == 11:
            if op.param3 == '1':
                if op.param1 in wait['pname']:
                    try:
                        G = cl.getGroup(op.param1)
                    except:
                        try:
                            G = k1.getGroup(op.param1)
                        except:
                            try:
                                G = k2.getGroup(op.param1)
                            except:
                                try:
                                    G = k3.getGroup(op.param1)
                                except:
                                    try:
                                        G = k4.getGroup(op.param1)
                                    except:
                                        try:
                                             G = k5.getGroup(op.param1)
                                        except:
                                            try:
                                                G = k6.getGroup(op.param1)
                                            except:
                                                 try:
                                                     G = k7.getGroup(op.param1)
                                                 except:
                                                 	try:
                                                 		G = k8.getGroup(op.param1)
                                                 	except:
                                                 		try:
                                                 			G = k9.getGroup(op.param1)
                                                 		except:
                                                 			try:
                                                 				G = k10.getGroup(op.param1)
                                                 			except:
                                                 				pass
                    G.name = wait['pro_name'][op.param1]
                    try:
                        cl.updateGroup(G)
                    except:
                        try:
                            k1.updateGroup(G)
                        except:
                            try:
                                k2.updateGroup(G)
                            except:
                                try:
                                    k3.updateGroup(G)
                                except:
                                    try:
                                        k4.updateGroup(G)
                                    except:
                                        try:
                                            k5.updateGroup(G)
                                        except:
                                        	try:
                                        		k6.updateGroup(G)
                                        	except:
                                        		try:
                                        			k7.updateGroup(G)
                                        		except:
                                        			try:
                                        				k8.updateGroup(G)
                                        			except:
                                        				try:
                                        					k9.updateGroup(G)
                                        				except:
                                        					try:
                                        						k10.updateGroup(G)
                                        					except:
                                        						pass
                    if op.param2 in ken:
                        pass
                    else:
                        try:
                            k1.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                k2.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    k3.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        k4.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            k5.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                        	try:
                                        		k6.kickoutFromGroup(op.param1,[op.param2])
                                        	except:
                                        		try:
                                        			k7.kickoutFromGroup(op.param1,[op.param2])
                                        		except:
                                        			try:
                                        				k8.kickoutFromGroup(op.param1,[op.param2])
                                        			except:
                                        				try:
                                        					k9.kickoutFromGroup(op.param1,[op.param2])
                                        				except:
                                        					try:
                                        						k10.kickoutFromGroup(op.param1,[op.param2])
                                        					except:
                                        						pass
                                        xs = [k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                                        xs.sendText(op.param1,"please do not change group name-_-")
                                        c = Message(to=op.param1, from_=None, text=None, contentType=13)
                                        c.contentMetadata={'mid':op.param2}
                                        cl.sendMessage(c)
#--------------------------------------------------------------------------------------------
        if op.type == 19:
            if mid in op.param3:
                wait["blacklist"][op.param2] = True

        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)

        if op.type == 55:
            try:
                if op.param1 in sider['readPoint']:
            
                    if op.param2 in sider['readMember'][op.param1]:
                        pass
                    else:
                        sider['readMember'][op.param1] += op.param2
                    sider['ROM'][op.param1][op.param2] = op.param2
                    with open('sider.json', 'w') as fp:
                       json.dump(sider, fp, sort_keys=True, indent=4)
                else:
                    pass
            except:
                pass

        if op.type == 19:
                if not op.param2 not in Bots and admin:
                    try:
                        gs = k1.getGroup(op.param1)
                        gs = k2.getGroup(op.param1)
                        gs = k3.getGroup(op.param1)
                        gs = k4.getGroup(op.param1)
                        gs = k5.getGroup(op.param1)
                        gs = k6.getGroup(op.param1)
                        gs = k7.getGroup(op.param1)
                        gs = k8.getGroup(op.param1)
                        gs = k9.getGroup(op.param1)
                        gs = k10.getGroup(op.param1)
                        targets = [op.param2]
                        for target in targets:
                           try:
                                wait["blacklist"][target] = True
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                           except:
                            pass
                    except Exception as e:
                        print (e)
                if not op.param2 in Bots and admin:
                  if wait["Backup"] == True:
                    try:
                        k1.inviteIntoGroup(op.param1, [op.param3])
                        k2.inviteIntoGroup(op.param1, [op.param3])
                        k3.inviteIntoGroup(op.param1, [op.param3])
                        k4.inviteIntoGroup(op.param1, [op.param3])
                        k5.inviteIntoGroup(op.param1, [op.param3])
                        k6.inviteIntoGroup(op.param1, [op.param3])
                        k7.inviteIntoGroup(op.param1, [op.param3])
                        k8.inviteIntoGroup(op.param1, [op.param3])
                        k9.inviteIntoGroup(op.param1, [op.param3])
                        k10.inviteIntoGroup(op.param1, [op.param3])
                    except Exception as e:
                        print (e)
                if not op.param2 in Bots and admin:
                  if wait["Backup"] == True:
                    try:
                        k1.inviteIntoGroup(op.param1, [op.param3])
                        k2.inviteIntoGroup(op.param1, [op.param3])
                        k3.inviteIntoGroup(op.param1, [op.param3])
                        k4.inviteIntoGroup(op.param1, [op.param3])
                        k5.inviteIntoGroup(op.param1, [op.param3])
                        k6.inviteIntoGroup(op.param1, [op.param3])
                        k7.inviteIntoGroup(op.param1, [op.param3])
                        k8.inviteIntoGroup(op.param1, [op.param3])
                        k9.inviteIntoGroup(op.param1, [op.param3])
                        k10.inviteIntoGroup(op.param1, [op.param3])
                    except Exception as e:
                        print (e)
                if not op.param2 not in Bots and admin:
                  if wait["Backup"] == True:
                    try:
                        k1.inviteIntoGroup(op.param1, [op.param3])
                        k2.inviteIntoGroup(op.param1, [op.param3])
                        k3.inviteIntoGroup(op.param1, [op.param3])
                        k4.inviteIntoGroup(op.param1, [op.param3])
                        k5.inviteIntoGroup(op.param1, [op.param3])
                        k6.inviteIntoGroup(op.param1, [op.param3])
                        k7.inviteIntoGroup(op.param1, [op.param3])
                        k8.inviteIntoGroup(op.param1, [op.param3])
                        k9.inviteIntoGroup(op.param1, [op.param3])
                        k10.inviteIntoGroup(op.param1, [op.param3])
                    except Exception as e:
                        print (e)
#-----------------------------------------------------------------------------------
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
                    cl.sendText(op.param1, "Blacklist Detected . . . Whitelist to invite . . ." + "\nDETIME: " + datetime.today().strftime(' [%H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

#===================================Protect backup====================================
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
               if wait["purgeOn"] == True:
                  klist=[k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                  random.choice(klist).kickoutFromGroup(op.param1, [op.param2])
        if op.type == 32:
            if op.param2 not in Bots and admin:
                if wait["protectCancel"] == True:
                    try:
                        klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                        random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                        random.choice(klist).inviteIntoGroup(op.param1, [op.param3])
                    except Exception as e:
                       print (e)
        if op.type == 13:
            if op.param2 not in Bots and admin:
                if wait["blockInviteOn"] == True:
                   klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                   Inviter = op.param3.replace("",',')
                   InviterX = Inviter.split(",")
                   random.choice(klist).cancelGroupInvitation(op.param1, InviterX)
                   pass
            if op.param2 not in Bots and admin:
                if wait["protectCancel"] == True:
                   klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                   random.choice(klist).kickoutFromGroup(op.param1, [op.param2])
                   wait["blacklist"][op.param2] = True
                   f=codecs.open('st2__b.json','w','utf-8')
                   json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                   pass
            if op.param2 not in Bots and admin:
              if wait["purgeOn"] == True:
                klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    random.choice(klist).cancelGroupInvitation(op.param1, matched_list)
                    k1.kickoutFromGroup(op.param1, [op.param2])
                    wait["blacklist"][op.param2] = True
                    f=codecs.open('st2__b.json','w','utf-8')
                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    k2.sendText(op.param1, "Don't invite Blacklist user!")

#---------------------------NOTIFIED_KICKOUT_FROM_GROUP------------------------
        if op.type == 19:
            if wait["AutoKick"] == True:
                try:
                    if op.param3 in Bots and admin:
                        pass
                        if op.param2 in Bots and admin:
                            pass
                        else:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                if op.param2 in wait["blacklist"]:
                                    pass
                                else:
                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                    k1.inviteIntoGroup(op.param1,[op.param3])
                                    k2.inviteIntoGroup(op.param1,[op.param3])
                                    k3.inviteIntoGroup(op.param1,[op.param3])
                                    k4.inviteIntoGroup(op.param1,[op.param3])
                                    k5.inviteIntoGroup(op.param1,[op.param3])
                                    k6.inviteIntoGroup(op.param1,[op.param3])
                                    k7.inviteIntoGroup(op.param1,[op.param3])
                                    k8.inviteIntoGroup(op.param1,[op.param3])
                                    k9.inviteIntoGroup(op.param1,[op.param3])
                                    k10.inviteIntoGroup(op.param1,[op.param3])
                    if op.param2 not in Bots and admin:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                if op.param2 in wait["blacklist"]:
                                    pass
                                else:
                                    random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                except:
                    print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                    if op.param2 in wait["blacklist"]:
                            pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            if op.param2 in wait["blacklist"]:
                                pass
                            else:
                                if op.param2 in Bots:
                                    pass
                                else:
                                    wait["blacklist"][op.param2] = True
                                    pass

        if op.type == 19:
            if wait["AutoKick"] == True:
                try:
                    if op.param3 in Bots and admin:
                        pass
                        if op.param2 in Bots and admin:
                            pass
                        else:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                if op.param2 in wait["blacklist"]:
                                    pass
                                else:
                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                    k1.inviteIntoGroup(op.param1,[op.param3])
                                    k2.inviteIntoGroup(op.param1,[op.param3])
                                    k3.inviteIntoGroup(op.param1,[op.param3])
                                    k4.inviteIntoGroup(op.param1,[op.param3])
                                    k5.inviteIntoGroup(op.param1,[op.param3])
                                    k6.inviteIntoGroup(op.param1,[op.param3])
                                    k7.inviteIntoGroup(op.param1,[op.param3])
                                    k8.inviteIntoGroup(op.param1,[op.param3])
                                    k9.inviteIntoGroup(op.param1,[op.param3])
                                    k10.inviteIntoGroup(op.param1,[op.param3])
                    if op.param2 not in Bots and admin:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                if op.param2 in wait["blacklist"]:
                                    pass
                                else:
                                    random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                except:
                    print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                    if op.param2 in wait["blacklist"]:
                            pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = False
                            if op.param2 in wait["blacklist"]:
                                pass
                            else:
                                if op.param2 in Bots:
                                    pass
                                else:
                                    wait["blacklist"][op.param2] = False
                                    pass

        if op.type == 13:
           if Bots in op.param3:
             if op.param1 in Bots and admin:
                G = cl.getGroup(op.param1)
                G = k1.getGroup(op.param1)
                G = k2.getGroup(op.param1)
                G = k3.getGroup(op.param1)
                G = k4.getGroup(op.param1)
                G = k5.getGroup(op.param1)
                G = k6.getGroup(op.param1)
                G = k7.getGroup(op.param1)
                G = k8.getGroup(op.param1)
                G = k9.getGroup(op.param1)
                G = k10.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            klist = [cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                            random.choice(klist).rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                            k1.acceptGroupInvitation(op.param1)
                            k2.acceptGroupInvitation(op.param1)
                            k3.acceptGroupInvitation(op.param1)
                            k4.acceptGroupInvitation(op.param1)
                            k5.acceptGroupInvitation(op.param1)
                            k6.acceptGroupInvitation(op.param1)
                            k7.acceptGroupInvitation(op.param1)
                            k8.acceptGroupInvitation(op.param1)
                            k9.acceptGroupInvitation(op.param1)
                            k10.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        k1.acceptGroupInvitation(op.param1)
                        k2.acceptGroupInvitation(op.param1)
                        k3.acceptGroupInvitation(op.param1)
                        k4.acceptGroupInvitation(op.param1)
                        k5.acceptGroupInvitation(op.param1)
                        k6.acceptGroupInvitation(op.param1)
                        k7.acceptGroupInvitation(op.param1)
                        k8.acceptGroupInvitation(op.param1)
                        k9.acceptGroupInvitation(op.param1)
                        k10.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        klist = [cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                        random.choice(klist).rejectGroupInvitation(op.param1)
#--------------------------------------------------------------------------------
        if op.type == 13:
            G = cl.getGroup(op.param1)
            I = G.creator
            if not op.param2 in Bots and admin:
                if wait["protectionOn"] == True:
                    klist=[cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                    kicker = random.choice(klist)
                    G = kicker.getGroup(op.param1)
                    if G is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        kicker.cancelGroupInvitation(op.param1, gInviMids)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                        cl.sendText(op.param1,"you are prohibited from inviting-_-")
                        c = Message(to=op.param1, from_=None, text=None, contentType=13)
                        c.contentMetadata={'mid':op.param2}
                        cl.sendMessage(c)
        if op.type == 13:
            if op.param3 in mid:
                if op.param2 in KAC:
                    G = random.choice(KAC).getGroup(op.param1)
                    G.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(G)
                    Ticket = blenk.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                    G.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(G)
                    Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Amid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    blenk.updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k1.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Bmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k2.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Cmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k3.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Dmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k4.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Emid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k5.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
#-----------------------------------------------------------
            if op.param3 in Fmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k6.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Gmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k7.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Hmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k8.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Imid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k9.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
            if op.param3 in Jmid:
                if op.param2 in KAC:
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    k10.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)

#-----------------------------------------------
        if op.type == 19:
            try:
                if op.param3 in mid:
                    if op.param2 in Amid:
                        G = k1.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k1.updateGroup(G)
                        Ticket = k1.reissueGroupTicket(op.param1)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                    else:
                        G = k2.getGroup(op.param1)

                        k1.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k1.updateGroup(G)
                        Ticket = k1.reissueGroupTicket(op.param1)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k1.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Amid:
                    if op.param2 in Bmid:
                        G = k2.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k2.updateGroup(G)
                        Ticket = k2.reissueGroupTicket(op.param1)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k1.updateGroup(G)
                    else:
                        G = k3.getGroup(op.param1)

                        k4.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k1.updateGroup(G)
                        Ticket = k1.reissueGroupTicket(op.param1)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k2.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Bmid:
                    if op.param2 in Cmid:
                        G = k3.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k3.updateGroup(G)
                        Ticket = k3.reissueGroupTicket(op.param1)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k2.updateGroup(G)
                    else:
                        G = k4.getGroup(op.param1)

                        k3.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k3.updateGroup(G)
                        Ticket = k3.reissueGroupTicket(op.param1)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k3.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Cmid:
                    if op.param2 in Dmid:
                        G = k4.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k4.updateGroup(G)
                        Ticket = k4.reissueGroupTicket(op.param1)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k3.updateGroup(G)
                    else:
                        G = k5.getGroup(op.param1)

                        k4.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k4.updateGroup(G)
                        Ticket = k4.reissueGroupTicket(op.param1)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k4.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Dmid:
                    if op.param2 in Emid:
                        G = k5.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k5.updateGroup(G)
                        Ticket = k5.reissueGroupTicket(op.param1)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k4.updateGroup(G)
                    else:
                        G = k6.getGroup(op.param1)

                        k5.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k5.updateGroup(G)
                        Ticket = k5.reissueGroupTicket(op.param1)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k5.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Emid:
                    if op.param2 in Fmid:
                        G = k6.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k6.updateGroup(G)
                        Ticket = k6.reissueGroupTicket(op.param1)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k5.updateGroup(G)
                    else:
                        G = k7.getGroup(op.param1)

                        k6.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k6.updateGroup(G)
                        Ticket = k6.reissueGroupTicket(op.param1)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k6.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Fmid:
                    if op.param2 in Gmid:
                        G = k7.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k7.updateGroup(G)
                        Ticket = k7.reissueGroupTicket(op.param1)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k6.updateGroup(G)
                    else:
                        G = k8.getGroup(op.param1)

                        k7.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k7.updateGroup(G)
                        Ticket = k7.reissueGroupTicket(op.param1)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k7.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Gmid:
                    if op.param2 in Hmid:
                        G = k8.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k8.updateGroup(G)
                        Ticket = k8.reissueGroupTicket(op.param1)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k7.updateGroup(G)
                    else:
                        G = k9.getGroup(op.param1)

                        k8.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k8.updateGroup(G)
                        Ticket = k8.reissueGroupTicket(op.param1)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k8.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Hmid:
                    if op.param2 in Imid:
                        G = k9.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k9.updateGroup(G)
                        Ticket = k9.reissueGroupTicket(op.param1)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k9.updateGroup(G)
                    else:
                        G = k10.getGroup(op.param1)

                        k9.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k9.updateGroup(G)
                        Ticket = k9.reissueGroupTicket(op.param1)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k9.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Imid:
                    if op.param2 in Jmid:
                        G = k10.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        k10.updateGroup(G)
                        Ticket = k10.reissueGroupTicket(op.param1)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k10.updateGroup(G)
                    else:
                        G = cl.getGroup(op.param1)

                        k10.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        k10.updateGroup(G)
                        Ticket = k10.reissueGroupTicket(op.param1)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        k10.updateGroup(G)
                        wait["blacklist"][op.param2] = True

                if op.param3 in Jmid:
                    if op.param2 in mid:
                        G = cl.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        Ticket = cl.reissueGroupTicket(op.param1)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                    else:
                        G = k1.getGroup(op.param1)

                        cl.kickoutFromGroup(op.param1,[op.param2])

                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        Ticket = cl.reissueGroupTicket(op.param1)
                        k10.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k9.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k5.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k6.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k7.acceptGroupInvitationByTicket(op.param1,Ticket)
                        k8.acceptGroupInvitationByTicket(op.param1,Ticket)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        wait["blacklist"][op.param2] = True
            except:
                pass
#---------------------------------------------------------------------------------
        if op.type == 55:
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n・ " + Name + datetime.today().strftime(' [ %H:%M:%S]')
                        wait2['ROM'][op.param1][op.param2] = "・ " + Name
                        wait2['setTime'][msg.to] = datetime.today().strftime('%H:%M:%S')
                else:
                    pass
            except:
                pass
#------------------------------NOTIFIED_READ_MESSAGE-----------------------------
        if op.type == 55:
         try:
             group_id = op.param1
             user_id=op.param2
             subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
         except Exception as e:
             print(e)
#---------------------------------------------------------------------------------
        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                k1.leaveRoom(op.param1)
                k2.leaveRoom(op.param1)
                k4.leaveRoom(op.param1)
                k5.leaveRoom(op.param1)
                k6.leaveRoom(op.param1)
                k7.leaveRoom(op.param1)
                k8.leaveRoom(op.param1)
                k9.leaveRoom(op.param1)
                k10.leaveRoom(op.param1)
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                k2.leaveRoom(op.param1)
                k4.leaveRoom(op.param1)
                k5.leaveRoom(op.param1)
                k6.leaveRoom(op.param1)
                k7.leaveRoom(op.param1)
                k8.leaveRoom(op.param1)
                k9.leaveRoom(op.param1)
                k10.leaveRoom(op.param1)
        if op.type == 26:
            msg = op.message
            send = msg.to
            if wait["talkban"] == True:
             if msg.from_ in wait["talkblacklist"]:
                try:
                    cl.sendText(send,cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10.getContact(msg.from_).displayName + " Jangan Ngomong dudul . . .")
                    cl.kickoutFromGroup(send,[msg.from_])
                    k1.kickoutFromGroup(msg.to,[msg.from_])
                    k2.kickoutFromGroup(msg.to,[msg.from_])
                    k3.kickoutFromGroup(msg.to,[msg.from_])
                    k4.kickoutFromGroup(msg.to,[msg.from_])
                    k5.kickoutFromGroup(msg.to,[msg.from_])
                    k6.kickoutFromGroup(msg.to,[msg.from_])
                    k7.kickoutFromGroup(msg.to,[msg.from_])
                    k8.kickoutFromGroup(msg.to,[msg.from_])
                    k9.kickoutFromGroup(msg.to,[msg.from_])
                    k10.kickoutFromGroup(msg.to,[msg.from_])
                except:
                    try:
                        cl.sendText(send,cl.getContact(msg.from_).displayName + " Jangan Ngomong dudul . . .")
                        cl.kickoutFromGroup(send,[msg.from_])
                    except:
                        cl.sendText(send,k2.getContact(msg.from_).displayName + " Jangan Ngomong dudul . . .")
                        k2.kickoutFromGroup(send,[msg.from_])
        
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
               if wait["talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["talkblacklist"]:
                        contact = k1.getContact(msg.contentMetadata["mid"])
                        k1.sendText(send,contact.displayName + " Already in Talkban")
                        wait["talkwblacklist"] = False
                    else:
                        wait["talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["talkwblacklist"] = False
                        contact = k1.getContact(msg.contentMetadata["mid"])
                        k1.sendText(send,contact.displayName + " Sukses Add to Talkban")
               elif wait["talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["talkblacklist"]:
                        del wait["talkblacklist"][msg.contentMetadata["mid"]]
                        contact = k1.getContact(msg.contentMetadata["mid"])
                        k1.sendText(send,contact.displayName + " Sukses Delete from Talkban")
                        wait["talkdblacklist"] = False
                    else:
                        wait["talkdblacklist"] = False
                        contact = k1.getContact(msg.contentMetadata["mid"])
                        k1.sendText(send,contact.displayName + " Not In Talkban")

        if op.type == 26:
            msg = op.message
            if msg.to in settings["simiSimi"]:
                if settings["simiSimi"][msg.to] == True:
                    if msg.text is not None:
                        text = msg.text
                        r = requests.get("http://api.ntcorp.us/chatbot/v1/?text=" + text.replace(" ","+") + "&key=beta1.nt")
                        data = r.text
                        data = json.loads(data)
                        if data['status'] == 200:
                            if data['result']['result'] == 100:
                                cl.sendText(msg.to, " " + data['result']['response'].encode('utf-8'))

        if op.type == 26:
            msg = op.message
            if msg.to in settings["chatbot"]:
                if settings["chatbot"][msg.to] == True:
                    if msg.text is not None:
                        text = msg.text
                        r = requests.get("http://api.ntcorp.us/chatbot/v1/?text=" + text.replace(" ","+") + "&key=beta1.nt")
                        data = r.text
                        data = json.loads(data)
                        if data['status'] == 200:
                            if data['result']['result'] == 100:
                                cl.sendText(msg.to, "" + data['result']['response'].encode('utf-8'))

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     balas = ["Im busy , please leave a message",cName + " Iya apa",cName + " tidur jam segini "," -_-"," is busy", cName + " Ditag bot -,-"," Urgent pc aja" + cName, "Dont tag me Bitch " + cName, " Ape ?" + cName + " ", "  " + cName + " "," Apaan"," Bot sange (-_-)!"]
                     ret_ = "[Auto Respon Tag]\n\n " + random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  break            
                    
            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["kickMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     balas = [" ",cName + " ",cName + " "," "," ", cName + " ","  " + cName, " " + cName, " " + cName + " ", " " + cName + " "," "," "]
                     ret_ = "SHUT UP THE FUCK OFF . . ." + random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,ret_)
                                  cl.kickoutFromGroup(msg.to,[msg.from_])
                                  k1.kickoutFromGroup(msg.to,[msg.from_])
                                  k2.kickoutFromGroup(msg.to,[msg.from_])
                                  k3.kickoutFromGroup(msg.to,[msg.from_])
                                  k4.kickoutFromGroup(msg.to,[msg.from_])
                                  k5.kickoutFromGroup(msg.to,[msg.from_])
                                  k6.kickoutFromGroup(msg.to,[msg.from_])
                                  k7.kickoutFromGroup(msg.to,[msg.from_])
                                  k8.kickoutFromGroup(msg.to,[msg.from_])
                                  k9.kickoutFromGroup(msg.to,[msg.from_])
                                  k10.kickoutFromGroup(msg.to,[msg.from_])
                                  break

        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
               if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"already add the acount whitelist . . .")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"decided not to comment")
               elif wait["dblack"] == True:
                   if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted acount fom the black list.  . .")
                        wait["dblack"] = False
                   else:
                        wait["dblack"] = False
                        cl.sendText(msg.to,"It is not in the black list")
               elif wait["wblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"already")
                        wait["wblacklist"] = False
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendText(msg.to,"aded")
               elif wait["dblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted")
                        wait["dblacklist"] = False
                   else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"It is not in the black list")
#--------------------------------------REPEAT_BAN----------------------------------------
               elif wait["rblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"Already in Blacklis now.  . .")
                        wait["rblacklist"] = True
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["rblacklist"] = True
                        cl.sendText(msg.to,"Succes add the  Black list . . .")
               elif wait["rdblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Succes add the blacklist . . .")
                        wait["rdblacklist"] = True
                   else:
                        wait["rdblacklist"] = True
                        cl.sendText(msg.to,"It is not in the black list . . .")
#---------------------------------------REPEAT_BAN----------------------------------------
               elif wait["contact"] == True:
                    msg.contentType = 0
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"➽ Profile Name :\n" + msg.contentMetadata["displayName"] + "\n\n➽ Mid :\n" + msg.contentMetadata["mid"] + "\n\n➽ Status Message :\n" + contact.statusMessage + "\n\n➽ Pict Status :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n➽ Cover Status :\n" + str(cu) + "\n\n     ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"➽ Profile Name :\n" + contact.displayName + "\n\n➽ Mid :\n" + msg.contentMetadata["mid"] + "\n\n➽ Status Mesage:\n" + contact.statusMessage + "\n\n➽ Pict Status :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n➽ Cover Status :\n" + str(cu) + "\n\n   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
#-------------------------------------------------------------------------------------
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)

            elif msg.text is None:
                return
            elif msg.text in ["Help","help"]:
              if msg.from_ in admin:
                print ("[HELP_ALL_COMMENT_EXCUTED]")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to, helpMessage + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,helpt)

            elif msg.text in ["Flist"]:
                if msg.from_ in admin:
                    if wait["teman"] == {}:
                        cl.sendText(msg.to,"nothing")
                    else:
                        cl.sendText(msg.to,"Daftar teman teman ku ada dibawah ini")
                        mc = ""
                        for mi_d in wait["teman"]:
                            mc += "->" +cl.getContact(mi_d).displayName + "\n"
                            cl.sendText(msg.to,mc)

            elif msg.text in ["Accept invite"]:
                if msg.from_ in admin:
                    gid = cl.getGroupIdsInvited()
                    _list = ""
                    for i in gid:
                        if i is not None:
                            gids = cl.getGroup(i)
                            _list += gids.name
                            cl.acceptGroupInvitation(i)
                        else:
                            break
                    if gid is not None:
                        cl.sendText(msg.to,"Berhasil terima semua undangan dari grup :\n" + _list)
                    else:
                        cl.sendText(msg.to,"Tidak ada grup yang tertunda saat ini")

            elif ("Gn: " in msg.text):
                if msg.toType == 2:
                    klist=[ck,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                    anu = random.choice(klist)
                    G = anu.getGroup(msg.to)
                    G.name = msg.text.replace("Gn: ","")
                    anu.updateGroup(G)
                else:
                    anu.sendText(msg.to,"Not for use less than group")

            elif "Invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Invite: ","")
                    cl.findAndAddContactsByMid(midd)
                    cl.inviteIntoGroup(msg.to,[midd])
            elif "Neo1 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo1 invite: ","")
                    k1.findAndAddContactsByMid(midd)
                    k1.inviteIntoGroup(msg.to,[midd])
            elif "Neo2 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo2 invite: ","")
                    k2.findAndAddContactsByMid(midd)
                    k2.inviteIntoGroup(msg.to,[midd])
            elif "Neo3 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo3 invite: ","")
                    k3.findAndAddContactsByMid(midd)
                    k3.inviteIntoGroup(msg.to,[midd])
            elif "Neo4 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo4 invite: ","")
                    k4.findAndAddContactsByMid(midd)
                    k4.inviteIntoGroup(msg.to,[midd])
            elif "Neo5 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo5 invite: ","")
                    k5.findAndAddContactsByMid(midd)
                    k5.inviteIntoGroup(msg.to,[midd])
            elif "Neo6 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo6 invite: ","")
                    k6.findAndAddContactsByMid(midd)
                    k6.inviteIntoGroup(msg.to,[midd])
            elif "Neo7 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo7 invite: ","")
                    k7.findAndAddContactsByMid(midd)
                    k7.inviteIntoGroup(msg.to,[midd])
            elif "Neo8 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo8 invite: ","")
                    k8.findAndAddContactsByMid(midd)
                    k8.inviteIntoGroup(msg.to,[midd])
            elif "Neo9 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo9 invite: ","")
                    k9.findAndAddContactsByMid(midd)
                    k9.inviteIntoGroup(msg.to,[midd])
            elif "Neo10 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Neo10 invite: ","")
                    k10.findAndAddContactsByMid(midd)
                    k10.inviteIntoGroup(msg.to,[midd])
#-------------------------------------------------------------------------------------
            elif "Mystatus: " in msg.text:
                string = msg.text.replace("Mystatus: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = cl.getProfile()
                    profile.statusMessage = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo1 status: " in msg.text:
                string = msg.text.replace("Neo1 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k1.getProfile()
                    profile.statusMessage = string
                    k1.updateProfile(profile)
                    k1.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo2 status: " in msg.text:
                string = msg.text.replace("Neo2 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k2.getProfile()
                    profile.statusMessage = string
                    k2.updateProfile(profile)
                    k2.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo3 status: " in msg.text:
                string = msg.text.replace("Neo3 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k3.getProfile()
                    profile.statusMessage = string
                    k3.updateProfile(profile)
                    k3.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo4 status: " in msg.text:
                string = msg.text.replace("Neo4 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k4.getProfile()
                    profile.statusMessage = string
                    k4.updateProfile(profile)
                    k4.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo5 status: " in msg.text:
                string = msg.text.replace("Neo5 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k5.getProfile()
                    profile.statusMessage = string
                    k5.updateProfile(profile)
                    k5.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo6 status: " in msg.text:
                string = msg.text.replace("Neo6 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k6.getProfile()
                    profile.statusMessage = string
                    k6.updateProfile(profile)
                    k6.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo7 status: " in msg.text:
                string = msg.text.replace("Neo7 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k7.getProfile()
                    profile.statusMessage = string
                    k7.updateProfile(profile)
                    k7.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo8 status: " in msg.text:
                string = msg.text.replace("Neo8 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k8.getProfile()
                    profile.statusMessage = string
                    k8.updateProfile(profile)
                    k8.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo9 status: " in msg.text:
                string = msg.text.replace("Neo9 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k9.getProfile()
                    profile.statusMessage = string
                    k9.updateProfile(profile)
                    k9.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
            elif "Neo10 status: " in msg.text:
                string = msg.text.replace("Neo10 status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k10.getProfile()
                    profile.statusMessage = string
                    k10.updateProfile(profile)
                    k10.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
#---------------------------------------------------------------------------------------
            elif "All status: " in msg.text:
                string = msg.text.replace("All status: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile = k1.getProfile()
                    profile.statusMessage = string
                    k1.updateProfile(profile)
                    k1.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k2.getProfile()
                    profile.statusMessage = string
                    k2.updateProfile(profile)
                    k2.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k3.getProfile()
                    profile.statusMessage = string
                    k3.updateProfile(profile)
                    k3.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k4.getProfile()
                    profile.statusMessage = string
                    k4.updateProfile(profile)
                    k4.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k5.getProfile()
                    profile.statusMessage = string
                    k5.updateProfile(profile)
                    k5.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")                                
                if len(string.decode('utf-8')) <= 500:
                    profile = k6.getProfile()
                    profile.statusMessage = string
                    k6.updateProfile(profile)
                    k6.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k7.getProfile()
                    profile.statusMessage = string
                    k7.updateProfile(profile)
                    k7.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k8.getProfile()
                    profile.statusMessage = string
                    k8.updateProfile(profile)
                    k8.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k9.getProfile()
                    profile.statusMessage = string
                    k9.updateProfile(profile)
                    k9.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
                if len(string.decode('utf-8')) <= 500:
                    profile = k10.getProfile()
                    profile.statusMessage = string
                    k10.updateProfile(profile)
                    k10.sendText(msg.to,"Status updated to: \n\n" + string + "\n\n done")
#--------------------------------------------------------------------------------------
            elif "Myname: " in msg.text:
                string = msg.text.replace("Myname: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Name update to:\n" + string + "")
            elif "Neo1 rename: " in msg.text:
                string = msg.text.replace("Neo1 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k1.getProfile()
                    profile.displayName = string
                    k1.updateProfile(profile)
                    k1.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo2 rename: " in msg.text:
                string = msg.text.replace("Neo2 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k2.getProfile()
                    profile.displayName = string
                    k2.updateProfile(profile)
                    k2.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo3 rename: " in msg.text:
                string = msg.text.replace("Neo3 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k3.getProfile()
                    profile.displayName = string
                    k3.updateProfile(profile)
                    k3.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo4 rename: " in msg.text:
                string = msg.text.replace("Neo4 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k4.getProfile()
                    profile.displayName = string
                    k4.updateProfile(profile)
                    k4.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo5 rename: " in msg.text:
                string = msg.text.replace("Neo5 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k5.getProfile()
                    profile.displayName = string
                    k5.updateProfile(profile)
                    k5.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo6 rename: " in msg.text:
                string = msg.text.replace("Neo6 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k6.getProfile()
                    profile.displayName = string
                    k6.updateProfile(profile)
                    k6.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo7 rename: " in msg.text:
                string = msg.text.replace("Neo7 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k7.getProfile()
                    profile.displayName = string
                    k7.updateProfile(profile)
                    k7.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo8 rename: " in msg.text:
                string = msg.text.replace("Neo8 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k8.getProfile()
                    profile.displayName = string
                    k8.updateProfile(profile)
                    k8.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo9 rename: " in msg.text:
                string = msg.text.replace("Neo9 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k9.getProfile()
                    profile.displayName = string
                    k9.updateProfile(profile)
                    k9.sendText(msg.to,"Name updated to:\n" + string + "")
            elif "Neo10 rename: " in msg.text:
                string = msg.text.replace("Neo10 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k10.getProfile()
                    profile.displayName = string
                    k10.updateProfile(profile)
                    k10.sendText(msg.to,"Name updated to:\n" + string + "")
#---------------------------------------------------------------------------------------
            elif "All rename: " in msg.text:
                string = msg.text.replace("All rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = k1.getProfile()
                    profile.displayName = string
                    k1.updateProfile(profile)
                    k1.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k2.getProfile()
                    profile.displayName = string
                    k2.updateProfile(profile)
                    k2.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k3.getProfile()
                    profile.displayName = string
                    k3.updateProfile(profile)
                    k3.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k4.getProfile()
                    profile.displayName = string
                    k4.updateProfile(profile)
                    k4.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k5.getProfile()
                    profile.displayName = string
                    k5.updateProfile(profile)
                    k5.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k6.getProfile()
                    profile.displayName = string
                    k6.updateProfile(profile)
                    k6.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k7.getProfile()
                    profile.displayName = string
                    k7.updateProfile(profile)
                    k7.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k8.getProfile()
                    profile.displayName = string
                    k8.updateProfile(profile)
                    k8.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k9.getProfile()
                    profile.displayName = string
                    k9.updateProfile(profile)
                    k9.sendText(msg.to,"Name updated to:\n" + string + "")
                if len(string.decode('utf-8')) <= 20:
                    profile = k10.getProfile()
                    profile.displayName = string
                    k10.updateProfile(profile)
                    k10.sendText(msg.to,"Name updated to:\n" + string + "")
#------------------------------------------------------------------------------------------
            elif msg.text in ["Mybackup"]:
                try:
                    cl.updateDisplayPicture(mybackup.pictureStatus)
                    cl.updateProfile(mybackup)
                    cl.sendText(msg.to, "Backup Sukses . . .")
                except Exception as e:
                    cl.sendText(msg.to, str (e))
            elif msg.text in ["Neo1 backup"]:
                try:
                    k1.updateDisplayPicture(mybackup.pictureStatus)
                    k1.updateProfile(backup1)
                    k1.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k1.sendText(msg.to, str (e))
            elif msg.text in ["Neo2 backup"]:
                try:
                    k2.updateDisplayPicture(mybackup.pictureStatus)
                    k2.updateProfile(backup2)
                    k2.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k2.sendText(msg.to, str (e))
            elif msg.text in ["Neo3 backup"]:
                try:
                    k3.updateDisplayPicture(mybackup.pictureStatus)
                    k3.updateProfile(backup3)
                    k3.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k3.sendText(msg.to, str (e))
            elif msg.text in ["Neo4 backup"]:
                try:
                    k4.updateDisplayPicture(mybackup.pictureStatus)
                    k4.updateProfile(backup4)
                    k4.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k4.sendText(msg.to, str (e))
            elif msg.text in ["Neo5 backup"]:
                try:
                    k5.updateDisplayPicture(mybackup.pictureStatus)
                    k5.updateProfile(backup5)
                    k5.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k5.sendText(msg.to, str (e))
            elif msg.text in ["Neo6 backup"]:
                try:
                    k6.updateDisplayPicture(mybackup.pictureStatus)
                    k6.updateProfile(backup6)
                    k6.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k6.sendText(msg.to, str (e))
            elif msg.text in ["Neo7 backup"]:
                try:
                    k7.updateDisplayPicture(mybackup.pictureStatus)
                    k7.updateProfile(backup7)
                    k7.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k7.sendText(msg.to, str (e))
            elif msg.text in ["Neo8 backup"]:
                try:
                    k8.updateDisplayPicture(mybackup.pictureStatus)
                    k8.updateProfile(backup8)
                    k8.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k8.sendText(msg.to, str (e))
            elif msg.text in ["Neo9 backup"]:
                try:
                    k9.updateDisplayPicture(mybackup.pictureStatus)
                    k9.updateProfile(backup9)
                    k9.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k9.sendText(msg.to, str (e))
            elif msg.text in ["Neo10 backup"]:
                try:
                    k10.updateDisplayPicture(mybackup.pictureStatus)
                    k10.updateProfile(backup10)
                    k10.sendText(msg.to, "Ready bot backup Sukses . . .")
                except Exception as e:
                    k10.sendText(msg.to, str (e))

            elif msg.text in ["All backup profile"]:
                try:
                    cl.updateDisplayPicture(mybackup.pictureStatus)
                    cl.updateProfile(mybackup)
                    k1.updateDisplayPicture(backup1.pictureStatus)
                    k1.updateProfile(backup1)
                    k2.updateDisplayPicture(backup2.pictureStatus)
                    k2.updateProfile(backup2)
                    k3.updateDisplayPicture(backup3.pictureStatus)
                    k3.updateProfile(backup3)
                    k4.updateDisplayPicture(backup4.pictureStatus)
                    k4.updateProfile(backup4)
                    k5.updateDisplayPicture(backup5.pictureStatus)
                    k5.updateProfile(backup5)
                    k6.updateDisplayPicture(backup6.pictureStatus)
                    k6.updateProfile(backup6)
                    k7.updateDisplayPicture(backup7.pictureStatus)
                    k7.updateProfile(backup7)
                    k8.updateDisplayPicture(backup8.pictureStatus)
                    k8.updateProfile(backup8)
                    k9.updateDisplayPicture(backup9.pictureStatus)
                    k9.updateProfile(backup9)
                    k10.updateDisplayPicture(backup10.pictureStatus)
                    k10.updateProfile(backup10)
                    cl.sendText(msg.to, "Backup Sukses . . .")
                    k1.sendText(msg.to, "Backup Sukses . . .")
                    k2.sendText(msg.to, "Backup Sukses . . .")
                    k3.sendText(msg.to, "Backup Sukses . . .")
                    k4.sendText(msg.to, "Backup Sukses . . .")
                    k5.sendText(msg.to, "Backup Sukses . . .")
                    k6.sendText(msg.to, "Backup Sukses . . .")
                    k7.sendText(msg.to, "Backup Sukses . . .")
                    k8.sendText(msg.to, "Backup Sukses . . .")
                    k9.sendText(msg.to, "Backup Sukses . . .")
                    k10.sendText(msg.to, "Backup Sukses . . .")
                except Exception as e:
                    cl.sendText(msg.to, str (e))
#---------------------------------------------------------------------------------
            elif "Me" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
            elif "Bot1" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                k1.sendMessage(msg)
            elif "Bot2" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                k2.sendMessage(msg)
            elif "Bot3" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                k3.sendMessage(msg)
            elif "Bot4" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                k4.sendMessage(msg)
            elif "Bot5" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Emid}
                k5.sendMessage(msg)
            elif "Bot6" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Fmid}
                k6.sendMessage(msg)
            elif "Bot7" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Gmid}
                k7.sendMessage(msg)
            elif "Bot8" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Hmid}
                k8.sendMessage(msg)
            elif "Bot9" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Imid}
                k9.sendMessage(msg)
            elif "Bot10" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Jmid}
                k10.sendMessage(msg)
            elif msg.text.lower() == 'mybots':
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Emid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Fmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Gmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Hmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Imid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Jmid}
                cl.sendMessage(msg)

            elif "Creator" == msg.text:
                msg.contentType = 13
                msg = cl.get.contentMetadata = {'mid': 'u05f4feb235542b74ef4538db57f2a0bd'}
                cl. sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                cl. sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                cl. sendMessage(msg)
            elif "Bot1 creator" == msg.text:
                msg.contentType = 13
                msg = cl.get.contentMetadata = {'mid': 'u05f4feb235542b74ef4538db57f2a0bd'}
                k1.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                k1.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                k1.sendMessage(msg)
            elif "Bot2 creator" == msg.text:
                msg.contentType = 13
                msg = cl.get.contentMetadata = {'mid': 'u05f4feb235542b74ef4538db57f2a0bd'}
                k2.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                k2.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                k2.sendMessage(msg)
            elif "Bot3 creator" == msg.text:
                msg.contentType = 13
                msg = cl.get.contentMetadata = {'mid': 'u05f4feb235542b74ef4538db57f2a0bd'}
                k3.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                k3.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                k3.sendMessage(msg)

            elif msg.text in ["Gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '2'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift1"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'af2d64ad-ccd2-49fa-8fb4-25ae2836a369',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '5'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift2"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'f44b6a1a-bdfa-47f7-a839-e7938eb71aac',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '7'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift3"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': '89131c1a-e549-4bd5-9e60-e24de0d2e252',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '10'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Bot1 gift","Neo1 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}
                msg.text = None
                k1.sendMessage(msg)
            elif msg.text in ["Bot2 gift","Neo2 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '8'}
                msg.text = None
                k2.sendMessage(msg)
            elif msg.text in ["Bot3 gift","Neo3 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '9'}
                msg.text = None
                k3.sendMessage(msg)
            elif msg.text in ["Bot4 gift","Neo4 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k4.sendMessage(msg)
            elif msg.text in ["Bot5 gift","Neo5 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k5.sendMessage(msg)
            elif msg.text in ["Bot6 gift","Neo6 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k6.sendMessage(msg)
            elif msg.text in ["Bot7 gift","Neo7 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k7.sendMessage(msg)
            elif msg.text in ["Bot8 gift","Neo8 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k8.sendMessage(msg)
            elif msg.text in ["Bot9 gift","Neo9 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k9.sendMessage(msg)
            elif msg.text in ["Bot10 gift","Neo10 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                k10.sendMessage(msg)
            elif msg.text in ["Allgift","All gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '12'}
                msg.text = None
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
                k10.sendMessage(msg)
                cl.sendMessage(msg)

            elif "Group pict" in msg.text:
              if msg.from_ in admin:
                  group = cl.getGroup(msg.to)
                  path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                  cl.sendImageWithURL(msg.to,path)
            elif "bot:off" in msg.text:
               if msg.from_ in creator:
                 try:
                     import sys
                     sys.exit()
                 except:
                     pass

            elif msg.text.lower() == 'run time':
                eltime = time.time()
                dan = "Bot sudah berjalan selama "+waktu(eltime)
                cl.sendText(msg.to,dan)

            elif "Steal bio" in msg.text:
            	if msg.from_ in admin:
            		key = eval(msg.contentMetadata["MENTION"])
            		key1 = key["MENTIONEES"][0]["M"]
            		contact = cl.getContact(key1)
            		cu = cl.channel.getCover(key1)
            	try:
            		cl.sendText(msg.to,contact.statusMessage)
            	except:
            		cl.sendText(msg.to,contact.statusMessage)

            elif ("Staff:on " in msg.text):
              if msg.from_ in creator:
                 if msg.toType == 2:
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                            admin.append(target)
                            cl.sendText(msg.to,"Succes Staff Added . . .")
                            print ("[Command]Staff add executed")
                        except:
                            pass
              else:
                   cl.sendText(msg.to,"Command denied . . .")
                   cl.sendText(msg.to,"Owner permission required . . .")

            elif ("Expel:on " in msg.text):
              if msg.from_ in creator:
                 if msg.toType == 2:
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                            admin.remove(target)
                            cl.sendText(msg.to,"Succes Deleting staff . . .")
                            print ("[Command]Staff remove executed")
                        except:
                            pass
              else:
                   cl.sendText(msg.to,"Command denied . . .")
                   cl.sendText(msg.to,"Owner permission required . . .")

            elif msg.text in ["Staff list"]:
                if admin == []:
                    cl.sendText(msg.to,"The StaffList is empty . . .")
                else:
                    cl.sendText(msg.to,"Waiting list...")
                    num=1
                    mc = "              STAFF LIST"
                    for mi_d in admin:
                        mc += "\n%i. %s" % (num, cl.getContact(mi_d).displayName)
                        num=(num+1)
                    cl.sendText(msg.to, mc +"\n-----------------------------------\n ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    print ("[STAFF READING LIST]")

            elif msg.text in ["Batal","Cancel","Cancel invites","Clean invites"]:
                if msg.toType == 2:
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"No one is inviting . . .")
                        else:
                            cl.sendText(msg.to,"Sorry, nobody absent . . .")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        cl.sendText(msg.to,"Not for use less than group  . . .")
            elif msg.text in ["Bot cancel","Neo clean invites"]:
                if msg.toType == 2:
                    neo = random.choice(KAC2)
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        neo.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            neo.sendText(msg.to,"No one is inviting . . .")
                        else:
                            neo.sendText(msg.to,"Sorry, nobody absent . . .")
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        anu.sendText(msg.to,"Not for use less than group . . .")

            elif msg.text in ["Link on","Ourl","Qron"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        a
                        cl.sendText(msg.to,"Done . . . qr is opened . . .")
                    else:
                        cl.sendText(msg.to,"URL is ready open . . .")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        cl.sendText(msg.to,"Not for use less than group . . .")
            elif msg.text in ["Slink on","Neo qron"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    anu = random.choice(klist)
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    anu.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done . . . qr is opened . . .")
                    else:
                        anu.sendText(msg.to,"URL is already open . . .")
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        anu.sendText(msg.to,"Not for use less than group . . .")

            elif msg.text in ["Link off","Qroff"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done . . . qr already opened . . .")
                    else:
                        cl.sendText(msg.to,"Qr is already close . . .")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        cl.sendText(msg.to,"Not for use less than group . . .")
            elif msg.text in ["Slink off","Neo qroff"]:
                if msg.toType == 2:
                    klist=[k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                    anu = random.choice(klist)
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    anu.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done . . . qr already opened . . .")
                    else:
                        anu.sendText(msg.to,"Already close . . .")
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        anu.sendText(msg.to,"Not for use less than group . . .")

            elif msg.text == "Ginfo":
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "[Error]"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventJoinByTicket == True:
                            u = "Close"
                        else:
                            u = "Open"
                        cl.sendText(msg.to,"⎆ Group Name :\n" + str(ginfo.name) + "\n⎆Group ID :\n" + msg.to + "\n Group Creator :\n" + gCreator + "\n Group Picture :\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\n[Group Members] : [" + str(len(ginfo.members)) + "] user\n[Pending Members] : [" + sinvitee + "] user\n\n QR Status : " + u + "\n\n    ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    else:
                        cl.sendText(msg.to,"⎆ Group Name :\n" + str(ginfo.name) + "\n⎆ Group ID :\n" + msg.to + "\n Group Creator :\n" + gCreator + "\n Group Picture :\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group . . .")
                    else:
                        cl.sendText(msg.to,"Not for use less than group . . .")
            elif msg.text in ["Glist","Mygroups"]:
                gs = cl.getGroupIdsJoined()
                L = "❝Groups List❞\n"
                num=1
                for i in gs:
                    L += "\n%i. %s " % (num, cl.getGroup(i).name + " ➡ " + str(len (cl.getGroup(i).members)))
                    num=(num+1)
                L += "\n\n➽ Total Groups : [ %i ]" % len(gs)
                cl.sendText(msg.to, L + "")
            elif msg.text in ["All gid","Allgid"]:
                gid1 = cl.getGroupIdsJoined()
                gid2 = k1.getGroupIdsJoined()
                gid3 = k2.getGroupIdsJoined()
                gid4 = k3.getGroupIdsJoined()
                G1 = "☆ Group ID ☆\n"
                G2 = "☆ Group ID ☆\n"
                G3 = "☆ Group ID ☆\n"
                G4 = "⭐ Group ID ☆\n"
                for i in gid1:
                    G1 += "⭐ %s\n%s\n" % (cl.getGroup(i).name, i)
                for i in gid2:
                    G2 += "⭐ %s\n%s\n" % (ki.getGroup(i).name, i)
                for i in gid3:
                    G3 += "⭐ %s\n%s\n" % (kk.getGroup(i).name, i)
                for i in gid4:
                    G4 += "⭐ %s\n%s\n" % (kc.getGroup(i).name, i)
                cl.sendText(msg.to, G1 + "\n\n⋙ Groups : [ " + str(len(gid1)) + " ]")
                k1.sendText(msg.to, G2 + "\n\n⋙ Groups : [ " + str(len(gid2)) + " ]")
                k2.sendText(msg.to, G3 + "\n\n⋙ Groups : [ " + str(len(gid3)) + " ]")
                k3.sendText(msg.to, G4 + "\n\n⋙ Groups : [ " + str(len(gid4)) + " ]")
            elif msg.text in ["Bot1glist"]:
                gs = k1.getGroupIdsJoined()
                L = "Groups List \n"
                for i in gs:
                    L += "╟ %s \n" % (ki.getGroup(i).name + " | [ " + str(len (ki.getGroup(i).members)) + " ]")
                k1.sendText(msg.to, L + "\n Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Bot2glist"]:
                gs = k2.getGroupIdsJoined()
                L = " Groups List \n"
                for i in gs:
                    L += "╟ %s \n" % (kk.getGroup(i).name + " | [ " + str(len (kk.getGroup(i).members)) + " ]")
                k2.sendText(msg.to, L + "\n☫ Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Bot3glist"]:
                gs = k3.getGroupIdsJoined()
                L = " Groups List \n"
                for i in gs:
                    L += "║ %s \n" % (kc.getGroup(i).name + " | [ " + str(len (kc.getGroup(i).members)) + " ]")
                k3.sendText(msg.to, L + "\n✖ Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Allglist"]:
                gs1 = cl.getGroupIdsJoined()
                gs2 = k1.getGroupIdsJoined()
                gs3 = k2.getGroupIdsJoined()
                gs4 = k3.getGroupIdsJoined()
                L1 = " Groups List \n"
                L2 = " Groups List \n"
                L3 = " Groups List \n"
                L4 = " Groups List \n"
                for i in gs1:
                    L1 += "║ %s \n" % (cl.getGroup(i).name + " | [ " + str(len (cl.getGroup(i).members)) + " ]")
                for i in gs2:
                    L2 += "║ %s \n" % (ki.getGroup(i).name + " | [ " + str(len (ki.getGroup(i).members)) + " ]")
                for i in gs3:
                    L3 += "║ %s \n" % (kk.getGroup(i).name + " | [ " + str(len (kk.getGroup(i).members)) + " ]")
                for i in gs4:
                    L4 += "║ %s \n" % (kc.getGroup(i).name + " | [ " + str(len (kc.getGroup(i).members)) + " ]")
                cl.sendText(msg.to, L1 + "\n Total Groups : [ " + str(len(gs1)) +" ]")
                k1.sendText(msg.to, L2 + "\n Total Groups : [ " + str(len(gs2)) +" ]")
                k2.sendText(msg.to, L3 + "\n Total Groups : [ " + str(len(gs3)) +" ]")
                k3.sendText(msg.to, L4 + "\n Total Groups : [ " + str(len(gs4)) +" ]")

            elif "Id" == msg.text:
                key = msg.to
                cl.sendText(msg.to, key)
            elif "Mid" == msg.text:
                cl.sendText(msg.to,mid)
            elif "Mid mid" == msg.text:
                cl.sendText(msg.to,mid)
                k1.sendText(msg.to,Amid)
                k2.sendText(msg.to,Bmid)
                k3.sendText(msg.to,Cmid)
                k4.sendText(msg.to,Dmid)
                k5.sendText(msg.to,Emid)
                k6.sendText(msg.to,Fmid)
                k7.sendText(msg.to,Gmid)
                k8.sendText(msg.to,Hmid)
                k9.sendText(msg.to,Imid)
                k10.sendText(msg.to,Jmid)
            elif "Bot mid" == msg.text:
                cl.sendText(msg.to,mid)
                cl.sendText(msg.to,Amid)
                cl.sendText(msg.to,Bmid)
                cl.sendText(msg.to,Cmid)
                cl.sendText(msg.to,Dmid)
                cl.sendText(msg.to,Emid)
                cl.sendText(msg.to,Fmid)
                cl.sendText(msg.to,Gmid)
                cl.sendText(msg.to,Hmid)
                cl.sendText(msg.to,Imid)
                cl.sendText(msg.to,Jmid)

            elif "Wkwk" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "100",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Hehe" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "10",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Galon" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "9",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "You" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "7",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Sue" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "105",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Huft" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "104",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Please" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "4",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Haaa" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "3",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Lol" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "110",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Hmmm" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "101",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            elif "Wc" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "247",
                                     "STKPKGID": "3",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
#============================================
            elif "Say " in msg.text:
                bctxt = msg.text.replace("Say ","")
                k1.sendText(msg.to,(bctxt))
                k2.sendText(msg.to,(bctxt))
                k3.sendText(msg.to,(bctxt))
                k4.sendText(msg.to,(bctxt))
                k5.sendText(msg.to,(bctxt))
                k6.sendText(msg.to,(bctxt))
                k7.sendText(msg.to,(bctxt))
                k8.sendText(msg.to,(bctxt))
                k9.sendText(msg.to,(bctxt))
                k10.sendText(msg.to,(bctxt))
            elif "Bot say " in msg.text:
                saytxt = msg.text.replace("Bot say ","")
                klist=[k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                anu = random.choice(klist)
                anu.sendText(msg.to,(saytxt))
            elif msg.text in ["Neo say hi"]:
                ki.sendText(msg.to,"Hi buddy . . .")
                kk.sendText(msg.to,"Hi buddy . . .")
                kc.sendText(msg.to,"Hi Everybuddy . . .")
            elif msg.text in ["Ping"]:
                k1.sendText(msg.to,"PONG . . .")
                k2.sendText(msg.to,"PONG . . .")
                k3.sendText(msg.to,"PONG . . .")
                k4.sendText(msg.to,"PONG . . .")
                k5.sendText(msg.to,"PONG . . .")
                k6.sendText(msg.to,"PONG . . .")
                k7.sendText(msg.to,"PONG . . .")
                k8.sendText(msg.to,"PONG . . .")
                k9.sendText(msg.to,"PONG . . .")
                k10.sendText(msg.to,"PONG . . .")
            elif msg.text in ["Welcome"]:
                k1.sendText(msg.to,"Selamat datang kakak keceh . . .")
                k2.sendText(msg.to,"No baper no ribet yang penting kita happy . . .")
                k3.sendText(msg.to,"Semoga betah ya kak . . . 😊😘😘")
            elif msg.text in ["Respon","Responsename"]:
                s1 = k1.getProfile()
                k1.sendText(msg.to, s1.displayName)
                s2 = k2.getProfile()
                k2.sendText(msg.to, s2.displayName)
                s3 = k3.getProfile()
                k3.sendText(msg.to, s3.displayName)
                s4 = k4.getProfile()
                k4.sendText(msg.to, s4.displayName)
                s5 = k5.getProfile()
                k5.sendText(msg.to, s5.displayName)
                s6 = k6.getProfile()
                k6.sendText(msg.to, s6.displayName)
                s7 = k7.getProfile()
                k7.sendText(msg.to, s7.displayName)
                s8 = k8.getProfile()
                k8.sendText(msg.to, s8.displayName)
                s9 = k9.getProfile()
                k9.sendText(msg.to, s9.displayName)
                s10 = k10.getProfile()
                k10.sendText(msg.to, s10.displayName)
#============================================
            elif "All broadcast: " in msg.text:
                bctxt = msg.text.replace("All broadcast: ","")
                contact = cl.getAllContactIds()
                r9 = cl.getProfile()
                for cbc in contact:
                    cl.sendText(cbc,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k1.sendText(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k2.sendText(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k3.sendTrxt(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k4.sendText(cbc,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k5.sendText(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k6.sendText(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k7.sendTrxt(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k8.sendText(cbc,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k9.sendText(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
                    k10.sendText(cbs,(bctxt) + "\n\n[BROADCAST CONTACT]\n Messages from : " + (r9.displayName))
            elif "Pmcast: " in msg.text:
                bctxt = msg.text.replace("Pmcast: ", "")
                contact = cl.getAllContactIds()
                for cbc in contact:
                    cl.sendText(cbc,(bctxt))
            elif "Bot1 pmcast: " in msg.text:
                bctxt = msg.text.replace("Bot1 pmcast: ","Neo1 pmcast: ")
                contact = k1.getAllContactIds()
                for cbc in contact:
                    k1.sendText(cbc,(bctxt))
            elif "Bot2 pmcast: " in msg.text:
                bctxt = msg.text.replace("Bot2 pmcast: ","Neo2 pmcast: ")
                contact = k2.getAllContactIds()
                for cbc in contact:
                    k2.sendText(cbc,(bctxt))
            elif "Bot3 pmcast: " in msg.text:
                bctxt = msg.text.replace("Bot3 pmcast: ","Neo3 pmcast: ")
                contact = k3.getAllContactIds()
                for cbc in contact:
                    k3.sendText(cbc,(bctxt))
            elif "All groupcast: " in msg.text:
                bctxt = msg.text.replace("All groupcast: ","")
                group = cl.getGroupIdsJoined()
                for gbc in group:
                    cl.sendText(gbc,(bctxt))
                    k1.sendText(gbc,(bctxt))
                    k2.sendText(gbc,(bctxt))
                    k3.sendText(gbc,(bctxt))
            elif "Mygroupcast: " in msg.text:
                bctxt = msg.text.replace("Mygroupcast: ","")
                group = cl.getGroupIdsJoined()
                name = cl.getProfile()
                for gbc in group:
                    cl.sendText(gbc,(bctxt) + "\n\n[Broadcast Group]\n Messages from : " + (name.displayName))
            elif "Bot1 groupcast: " in msg.text:
                bctxt = msg.text.replace("Bot1 groupcast: ","Neo1 groupcast: ")
                group = k1.getGroupIdsJoined()
                for gbc in group:
                    k1.sendText(gbc,(bctxt))
            elif "Bot2 groupcast: " in msg.text:
                bctxt = msg.text.replace("Bot2 groupcast: ","Neo2 groupcast: ")
                group = k2.getGroupIdsJoined()
                for gbc in group:
                    k2.sendText(gbc,(bctxt))
            elif "Bot3 groupcast: " in msg.text:
                bctxt = msg.text.replace("Bot3 groupcast: ","Neo3 groupcast: ")
                group = k3.getGroupIdsJoined()
                for gbc in group:
                    k3.sendText(gbc,(bctxt))
#=============================================
            elif msg.text in ["Gcreator","Gc"]:
                if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)

            elif "Info @" in msg.text:
              if msg.from_ in admin:
                nama = msg.text.replace("Info @","")
                target = nama.rstrip(' ')
                tob = cl.getGroup(msg.to)
                for g in tob.members:
                    if target == g.displayName:
                        gjh= cl.getContact(g.mid)
                        try:
                            cover = cl.channel.getCover(g.mid)
                        except:
                            cover = ""
                        cl.sendText(msg.to,"[Display Name]:\n" + gjh.displayName + "\n[Mid]:\n" + gjh.mid + "\n[BIO]:\n" + gjh.statusMessage + "\n[pict profile]:\nhttp://dl.profile.line-cdn.net/" + gjh.pictureStatus + "\n[Cover]:\n" + str(cover))
                    else:
                        pass
#=========================================================
            elif "Tl: " in msg.text:
                tl_text = msg.text.replace("Tl: ","Timeline: ")
                cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])

#-----------------------------------------------
            elif ("Copy @" in msg.text):
                   print ("[MY_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendText(msg.to, "Not found . . .")
                   else:
                       for target in targets:
                            try:
                               cl.cloneContactProfile(target)
                               cl.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot1 copy @" in msg.text):
                   print ("[BOT1_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot1 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k1.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k1.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k1.cloneContactProfile(target)
                               k1.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot2 copy @" in msg.text):
                   print ("[BOT2_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot2 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k2.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k2.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k2.cloneContactProfile(target)
                               k2.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot3 copy @" in msg.text):
                   print ("[BOT3_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot3 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k3.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k3.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k3.cloneContactProfile(target)
                               k3.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot4 copy @" in msg.text):
                   print ("[BOT4_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot4 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k4.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k4.sendText(msg.to, "Not found . . .")
                   else:
                       for target in targets:
                            try:
                               k4.cloneContactProfile(target)
                               k4.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot5 copy @" in msg.text):
                   print ("[BOT5_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot5 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k5.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k5.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k5.cloneContactProfile(target)
                               k5.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot6 copy @" in msg.text):
                   print ("[BOT6_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot6 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k6.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k6.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k6.cloneContactProfile(target)
                               k6.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot7 copy @" in msg.text):
                   print ("[BOT7_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot7 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k7.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k7.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k7.cloneContactProfile(target)
                               k7.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot8 copy @" in msg.text):
                   print ("[BOT8_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot8 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k8.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k8.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k8.cloneContactProfile(target)
                               k8.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot9 copy @" in msg.text):
                   print ("[BOT9_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot9 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k9.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k9.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k9.cloneContactProfile(target)
                               k9.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)
            elif ("Bot10 copy @" in msg.text):
                   print ("[BOT10_COPY_DONE_SUCSSES]")
                   _name = msg.text.replace("Bot10 copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = k10.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       k10.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               k10.cloneContactProfile(target)
                               k10.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print (e)

#==================================================================            
            elif msg.text in ["Auto chat:on"]:
                settings["simiSimi"][msg.to] = True
                cl.sendText(msg.to,"Success activated Auto Chat Bot . . .")
                
            elif msg.text in ["Auto chat:off"]:
                settings["simiSimi"][msg.to] = False
                cl.sendText(msg.to,"Success deactived Auto Chat Bot . . .")

            elif msg.text in ["Autorespon:on","Tag respon:on"]:
                wait["detectMention"] = True
                cl.sendText(msg.to,"Auto Respon Turned ON . . .")
                
            elif msg.text in ["Autorespon:off","Tag respon:off"]:
                wait["detectMention"] = False
                cl.sendText(msg.to,"Auto Respon  Turned OFF . .  ")
            
            elif msg.text in ["Notag on","Notag:on"]:
                wait["kickMention"] = True
                cl.sendText(msg.to,"Sock is on the door! Now fuck off . . .")
                
            elif msg.text in ["Notag off","Notag:off"]:
                wait["kickMention"] = False
                cl.sendText(msg.to,"Notag has been deactived . . .")

            elif msg.text in ["Algojo:on"]:
                settings["siri"][msg.to] = True
                cl.sendText(msg.to,"Success activated Algojo code qr . . .")
                
            elif msg.text in ["Algojo:off"]:
                settings["siri"][msg.to] = False
                cl.sendText(msg.to,"Success deactived Algojo code qr . . .")
#==================================================================
            elif msg.text in ["Protect:on","Protect on"]:
                if wait["protectionOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect is already on . . .")
                    else:
                        cl.sendText(msg.to,"Protection On . . .")
                else:
                    wait["protectionOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection On . . .")
                    else:
                        cl.sendText(msg.to,"Protect Already on . . .")
#--------------------------------------------------------
            elif msg.text in ["Auto kick:on"]:
                if wait["AutoKick"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to, "Auto kick protect is turn on . . .")
                    else:
                         clsendText(msg.to,"Protect auto kick turn on . . .")
                else:
                    wait["AutoKick"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Auto kick is turned On . . .")
                    else:
                        cl.sendText(msg.to,"Already on . . .")
            elif msg.text in ["Auto kick:off"]:
                if wait["AutoKick"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to, "Auto kick protect is turn off . . .")
                    else:
                         clsendText(msg.to,"Protect auto kick turn off . . .")
                else:
                    wait["AutoKick"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Auto kick is turned Off . . .")
                    else:
                        cl.sendText(msg.to,"Already off . . . ")

            elif msg.text in ["Protect qr:off","Protect link:off","Qrprotect:off"]:
                if wait["qr"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Qr protect is Already off . . .")
                    else:
                        cl.sendText(msg.to,"Protection QR Off . . .")
                else:
                    wait["qr"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection QR Off . . .")
                    else:
                        cl.sendText(msg.to,"Already off . . .")
            elif msg.text in ["Protect qr:on","Protect link:on","Qrprotect:on"]:
                if wait["qr"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"protect qr is already on . . .")
                    else:
                        cl.sendText(msg.to,"Protection QR On . . .")
                else:
                    wait["qr"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection QR On . . .")
                    else:
                        cl.sendText(msg.to,"Protect qr Already on . . .")
            elif msg.text in ["Protect:off","Protect off"]:
                if wait["protectionOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection id already off . . .")
                    else:
                        cl.sendText(msg.to,"Protection Off . . .")
                else:
                    wait["protectionOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection already Off . . .")
                    else:
                        cl.sendText(msg.to,"Protection is lready off . . .")

            elif msg.text in ["Blockinvite:on","Blockinvite on"]:
                if wait["blockInviteOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny invite already on . . .")
                else:
                    wait["blockInviteOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny Invite Turned On . . .")
            elif msg.text in ["Blockinvite:off","Blockinvite off"]:
                if wait["blockInviteOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny invite already off . . .")
                else:
                    wait["blockInviteOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Deny Invite Turned Off . . .")

            elif msg.text in ["Protect invite on","Protect invite:on"]:
                if wait["protectCancel"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection already on . . .")
                else:
                    wait["protectCancel"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Invite on . . . Deny invite 2 turned On . . .\n\n °Warning!!!\n °Call admin for invite members\n °Don't rejected pending members!!!")
            elif msg.text in ["Protect invite:off","Protect invite off"]:
                if wait["protectCancel"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection invite 2 already off . . .")
                else:
                    wait["protectCancel"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Invite 2 is turned Off . . .")

            elif "Protect name:on" in msg.text:
                if msg.to in wait['pname']:
                    cl.sendText(msg.to,"Protact group name is turned on . . . don't chage name in a group you cant kick out from the group. . .")
                else:
                    cl.sendText(msg.to,"Protect group name already on . . . don't changed name group...  you can kick out from the group . . .")
                    wait['pname'][msg.to] = True
                    wait['pro_name'][msg.to] = cl.getGroup(msg.to).name
            elif "Protect name:off" in msg.text:
                if msg.to in wait['pname']:
                    cl.sendText(msg.to,"Protect group name is turned off . . .")
                    del wait['pname'][msg.to]
                else:
                    cl.sendText(msg.to,"Protect group name already off . . .")

            elif msg.text in ["K on","Contact:on","Contact on","K:on"]:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Contact is already on . . .")
                    else:
                        cl.sendText(msg.to,"done contact turned on . . .")
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"contact already on . . .")
                    else:
                        cl.sendText(msg.to,"done . . . contact turned on . . .")
            elif msg.text in ["K:off","Contact:off","Contact off","K off"]:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Contact is already off . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Contact turned off . . .")
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"contact already off . . .")
                    else:
                        cl.sendText(msg.to,"done . . . contact is turned off . . .")

            elif msg.text in ["Auto join on","Join on","Join:on","Auto join:on"]:
                if wait["autoJoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already on . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Auto join is turned on . . .")
                else:
                    wait["autoJoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already on . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Auto join is turned on . . .")
            elif msg.text in ["Join off","Auto join off","Auto join:off","Join:off"]:
                if wait["autoJoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already off . . .")
                    else:
                        cl.sendText(msg.to,"done . . . auto join is turned off . . .")
                else:
                    wait["autoJoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join already off . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Auto join is turned off . . .")

            elif "Gcancel " in msg.text:
                try:
                    strnum = msg.text.replace("Gcancel ","Neo Gcancel")
                    if strnum == "off":
                        wait["autoCancel"]["on"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invitation refused turned off\nTo turn on please specify the number of people and send")
                        else:
                            cl.sendText(msg.to,"关了邀请拒绝。要时开请指定人数发送")
                    else:
                        num =  int(strnum)
                        wait["autoCancel"]["on"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,strnum + " The group of people and below decided to automatically refuse invitation")
                        else:
                            cl.sendText(msg.to,strnum + "使人以下的小组用自动邀请拒绝")
                except:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Value is wrong")
                    else:
                        cl.sendText(msg.to,"Bizarre ratings")

            elif msg.text in ["Leave:on","Auto leave on","Auto leave:on","Leave on"]:
                if wait["leaveRoom"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto leave is already on . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Auto leave is turned on . . .")
                else:
                    wait["leaveRoom"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . Auto leave already on . . .")
                    else:
                        cl.sendText(msg.to,"Auto leave already turned on . . .")
            elif msg.text in ["Leave:off","Auto leave off","Auto leave:off","Leave off"]:
                if wait["leaveRoom"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto leave is already off . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Auto leave is turned off . . .")
                else:
                    wait["leaveRoom"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . auto leave is turned off . . .")
                    else:
                        cl.sendText(msg.to,"Aitu leave already off . . .")

            elif msg.text in ["共有:オン","Share on","Share:on"]:
                if wait["timeline"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Timeline share is already on . . .")
                    else:
                        cl.sendText(msg.to,"done . . Auto share is turned on . . .")
                else:
                    wait["timeline"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . auto share turned on . . .")
                    else:
                        cl.sendText(msg.to,"Auto share already turned on . . .")
            elif msg.text in ["共有:オフ","Share off","Share:off"]:
                if wait["timeline"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Timeline share is already off . . .")
                    else:
                        cl.sendText(msg.to,"done . . . Auto share is off . . .")
                else:
                    wait["timeline"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done . . . Auto share is off . . .")
                    else:
                        cl.sendText(msg.to,"Auto share already off . . .")

            elif msg.text in ["Auto like on","Like on","Auto like:on"]:
                if wait["likeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto like is already on now . . .")
                else:
                    wait["likeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto Like Turn On . . .")
            elif msg.text in ["Auto like off","Like off","Auto like:off"]:
                if wait["likeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto like is already off . . .")
                else:
                    wait["likeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto Like Turn off . . .")

            elif msg.text in ["Welcome on","Welcome:on","Wc on","Wc:on"]:
                if wait["welcomeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Messages auto welcome is already on . . .")
                else:
                    wait["welcomeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome Message Turn on . . .")
            elif msg.text in ["Welcome off","Welcome:off","Wc off","Wc:off"]:
                if wait["welcomeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome messages is already off . . .")
                else:
                    wait["welcomeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome Message Turn off . . .")
            elif msg.text in ["Auto purge on","Auto purge:on","Purge:on","Purge on"]:
                if wait["purgeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Purge swiching  already on . . .")
                else:
                    wait["purgeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto purge on . . .\n\n °Warning!!!\n °Don't invite member from Blacklist users")
            elif msg.text in ["Auto purge ff","Auto purge:off","Purge:off","Purge off"]:
                if wait["purgeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Purge swiching already off . . .")
                else:
                    wait["purgeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto purge is turned off . . .")

            elif msg.text in ["Status","Set"]:
            	print "[SETTINGS CHECK SET]"
                md = "⊷SETTINGS ACOUNT⊶\n--------------------------------\n"
                if wait["lurkingOn"] == True: md+="⋟ Lurk : on\n"
                else:md+="⋟ Lurk : off\n"
                if wait["clock"] == True: md+="⋟ Clock : on\n"
                else:md+="⋟ Clock : off\n"
                if wait["timeline"] == True: md+="⋟ Share : on\n"
                else:md+="⋟ Share : off\n"
                if wait["contact"] == True: md+="⋟ Contact : on\n"
                else:md+="⋟ Contact : off\n"
                if wait["autoJoin"] == True: md+="⋟ Auto join : on\n"
                else:md +="⋟ Auto join : off\n"
                if wait["autoAdd"] == True: md+="⋟ Auto add : on\n"
                else:md+="⋟ Auto add : off\n"
                if wait["likeOn"] == True: md+="⋟ Auto Like : on\n"
                else:md+="⋟ Auto Like : off\n"
                if wait["commentOn"] == True: md+="⋟ Comment : on\n"
                else:md+="⋟ Comment : off\n"
                if wait["leaveRoom"] == True: md+="⋟ Auto leave : on\n"
                else:md+="⋟ Auto leave : off\n"
                if wait["welcomeOn"] == True: md+="⋟ Welcome message : on\n"
                else:md+="⋟ Welcome message : off\n"
                if wait["autoCancel"]["on"] == True:md+="⋟ Group cancel panding :" + str(wait["autoCancel"]["members"]) + ": on\n-------------------------------\n⊷⌬SETTINGS PROTECT⌬⊶\n-------------------------------\n"
                else:md +="⋟ Group cancel panding : off\n\n\n⊷⌬SETTINGS PROTECT⌬⊶\n\n"
                if wait["purgeOn"] == True: md+="⋟ Auto purge : on\n"
                else:md+="⋟ Auto purge : off\n"
                if wait["Backup"] == True: md+="⋟ Backup : on\n"
                else:md+="⋟ Backup : off\n"
                if wait["protectCancel"] == True: md+="⋟ Protect invite : on\n"
                else:md+="⋟ Protect invite : off\n"
                if wait["blockInviteOn"] == True: md+="⋟ Block invite : on\n"
                else:md+="⋟ Block invite : off\n"
                if wait["pname"] == True: md+="⋟  Protect name : on\n"
                else:md+="⋟ Protect name : off\n"
                if wait["qr"] == True: md+="⋟ Protect Link : on\n"
                else:md+="⋟ Protect Link : off\n"
                if wait["protectionOn"] == True: md+="⋟ Protection : on\n"
                else:md+="⋟ Protection : off\n"
                if wait["atjointicket"] == True: md+="⋟ Auto join tickets:: on\n--------------------------------\n⊷༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"+ datetime.today().strftime(' [%H:%M:%S]')
                else:md+="⋟ Auto join tickets: off\n---------------------------------\n⊷༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"+ datetime.today().strftime(' [%H:%M:%S]')
                cl.sendText(msg.to,md)
#========================================
            elif msg.text in ["Backup:on","Backup on"]:
                if wait["Backup"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backuping member is already on . . .")
                    else:
                        cl.sendText(msg.to,"Backup is turned On . . .")
                else:
                    wait["Backup"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backup is turned On . . .")
                    else:
                        cl.sendText(msg.to,"Backuping member is lready on . . .")
            elif msg.text in ["Backup:off","Backup off"]:
                if wait["Backup"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backups already swiching  off . . .")
                    else:
                        cl.sendText(msg.to,"Backup is turned Off . . .")
                else:
                    wait["Backup"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backup is turned Off . . .")
                    else:
                        cl.sendText(msg.to,"Backups is already swiching off . . .")
            elif msg.text in ["Rgroups"]:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"All invitations have been rejected . . .")
                else:
                    cl.sendText(msg.to,"All invitation already refusrd . . .")
            elif msg.text in ["S1 rgroups","Bot1 rgroups","Neo1 rgroups"]:
                gid = ki.getGroupIdsInvited()
                for i in gid:
                    ki.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    ki.sendText(msg.to,"All invitations is clean . . . ")
                else:
                    ki.sendText(msg.to, "All invitation already refused . . .")
            elif msg.text in ["S2 rgroups","Bot2 rgroups","Neo2 rgruoups"]:
                gid = kk.getGroupIdsInvited()
                for i in gid:
                    kk.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    kk.sendText(msg.to,"All invitations is clean . . .")
                else:
                    kk.sendText(msg.to,"All invitation is already refused . . .")
            elif msg.text in ["Add:on","Auto add on","Auto add:on","Add on"]:
                if wait["autoAdd"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto add is already on . . . " )
                    else:
                        cl.sendText(msg.to,"Done . . . Auto add is turned on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["autoAdd"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . Auto add is turned on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto add Already turned on . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Add:off","Auto add off","Auto add:off","Add off"]:
                if wait["autoAdd"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto add is already off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Done . . . auto add is turned off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["autoAdd"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto add is turned off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto add Already off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Lurk:on","Lurking on","Cctv:on","Cctv on"]:
                if wait["lurkingOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Lurkers Already On . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Lurking Turned On Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["lurkingOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Lurking Turned On Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Lurkers Already On . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Lurk:off","Lurking off","Cctv:off","Cctv off"]:
                if wait["lurkingOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Lurking Turned Off Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["lurkingOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Lurking Turned Off Mode . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Already Off . . .\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))

#========================================
            elif "Update welcome: " in msg.text:
              if msg.from_ in admin:
                wait["welmsg"] = msg.text.replace("Update welcome: ","")
                cl.sendText(msg.to,"update welcome message succes")
            elif msg.text in ["Check welcome message"]:
              if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"yor bot message\n\n" + wait["welmsg"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as follows。\n\n" + wait["welmsg"])


            elif "Message: " in msg.text:
                wait["message"] = msg.text.replace("Message: ","")
                cl.sendText(msg.to,"message changed . . \n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif "Add message: " in msg.text:
                wait["message"] = msg.text.replace("Add message: ","")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message changed . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"done . . . messages is chage . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Message"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message change to\n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as follows。\n\n" + wait["message"])
            elif "Comment: " in msg.text:
                c = msg.text.replace("Comment: ","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif "Add comment: " in msg.text:
                c = msg.text.replace("Add comment: ","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)

            elif msg.text in ["Comment on","Comment:on"]:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto comment is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto command is already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto comment is turned on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto comment already on . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Comment off","Comment:off"]:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . auto comment is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto command is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done . . . Auto commend is turned off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Auto command is already off . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Comment check"]:
                cl.sendText(msg.to,"message changed to\n\n" + str(wait["comment"]))
            elif msg.text in ["Gurl"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.preventJoinByTicket == True:
                        X.preventJoinByTicket = False
                        cl.updateGroup(X)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#==================================================
            elif msg.text in ["Invite on","Invite:on"]:
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    cl.sendText(msg.to,"Send a contact to invite . . .")
            elif msg.text in ["Invite stop","Invite:stop"]:
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    cl.sendText(msg.to,"Invite Stoped . . .")
#========================================
            elif msg.text in ["Comment bl "]:
                wait["wblack"] = True
                cl.sendText(msg.to,"add to comment bl")
            elif msg.text in ["Comment wl "]:
                wait["dblack"] = True
                cl.sendText(msg.to,"wl to comment bl")
            elif msg.text in ["Comment bl confirm"]:
                if wait["commentBlack"] == {}:
                    cl.sendText(msg.to,"confirmed")
                else:
                    cl.sendText(msg.to,"Blacklist s")
                    mc = ""
                    for mi_d in wait["commentBlack"]:
                        mc += "・" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)

            elif msg.text in ["Clock:on","Clock on","Jam on","Jam:on"]:
                if wait["clock"] == True:
                    cl.sendText(msg.to,"Clock is already on . . .")
                else:
                    wait["clock"] = True
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"[%H:%M]")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"done . . .")

            elif msg.text in ["Clock:off","Clock off","Jam off","Jam:off"]:
                if wait["clock"] == False:
                    cl.sendText(msg.to,"Clock name already off . . .")
                else:
                    wait["clock"] = False
                    cl.sendText(msg.to,"done . . . clock name is turned off . . .")

            elif "Cc: " in msg.text:
                n = msg.text.replace("Cc: ","Update name: ","Myname: ")
                if len(n.decode("utf-8")) > 13:
                    cl.sendText(msg.to,"Sucsess name already changed . . .")
                else:
                    wait["cName"] = n
                    cl.sendText(msg.to,"Changed to:\n\n" + n)
            elif msg.text in ["Up"]:
                if wait["clock"] == True:
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"[%H:%M]")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Refresh to update name done . . .")
                else:
                    cl.sendText(msg.to,"Please turn on the name clock . . .")
            elif msg.text in ["Bot gurl"]:
                if msg.toType == 2:
                    anu = random.choice(KAC2)
                    X = cl.getGroup(msg.to)
                    if X.preventJoinByTicket == True:
                        X.preventJoinByTicket = False
                        anu.updateGroup(X)
                    gurl = anu.reissueGroupTicket(msg.to)
                    anu.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group")
                    else:
                        anu.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["G creator"]:
              if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)

            elif msg.text in ["All protect:off","All protect off"]:
                wait["protectionOn"] = False
                wait["qr"] = False
                wait["pname"] = False
                wait["Backup"] = False
                wait["blockInviteOn"] = False
                wait["protectCancel"] = False
                cl.sendText(msg.to,"Turn off All Protection . . .")
            elif msg.text in ["All protect:on","All protect on"]:
                wait["protectionOn"] = True
                wait["qr"] = True
                wait["pname"] = True
                wait["Backup"] = True
                wait["blockInviteOn"] = True
                wait["protectCancel"] = True
                cl.sendText(msg.to,"Turn On All Protection . . .")

#===========================================
            elif msg.text.lower() == 'group creator':
                if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)

            elif 'lyric ' in msg.text.lower():
              if msg.from_ in admin:
                try:
                    songname = msg.text.lower().replace('lyric ','')
                    params = {'songname': songname}
                    r = requests._getItem_('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Lyric Lagu ('
                        hasil += song[0]
                        hasil += ')\n\n'
                        hasil += song[5]
                        cl.sendText(msg.to, hasil)
                except Exception as wak:
                        cl.sendText(msg.to, str(wak))
            elif 'wiki ' in msg.text.lower():
              if msg.from_ in admin:
                  try:
                      wiki = msg.text.lower().replace("wiki ","")
                      wikipedia.set_lang("id")
                      pesan="Title ("
                      pesan+=wikipedia.page(wiki).title
                      pesan+=")\n\n"
                      pesan+=wikipedia.summary(wiki, sentences=1)
                      pesan+="\n"
                      pesan+=wikipedia.page(wiki).url
                      cl.sendText(msg.to, pesan)
                  except:
                          try:
                              pesan="Over Text Limit! Please Click link\n"
                              pesan+=wikipedia.page(wiki).url
                              cl.sendText(msg.to, pesan)
                          except Exception as e:
                              cl.sendText(msg.to, str(e))
            elif msg.text.lower() == 'reboot':
              if msg.from_ in admin:
                    print ("[Command]Like executed")
                    try:
                        cl.sendText(msg.to,"Restarting...")
                        restart_program()
                    except:
                        cl.sendText(msg.to,"Please wait")
                        restart_program()
                        pass

            elif "clean chat" in msg.text.lower():
                if msg.from_ in admin:
                    try:
                        cl.removeAllMessages(op.param2)
                        print ("[Command] Remove Chat")
                        cl.sendText(msg.to,"Sukses Menghapus Chat")
                    except Exception as error:
                        print (error)
                        cl.sendText(msg.to,"Error Menghapus Chat")

            elif "Play " in msg.text:
                songname = msg.text.replace(".Play ","")
                params = {"songname":songname}
                r = requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    cl.sendText(msg.to,"Judul : " + song[0] + "\nDurasi : " + song[1])
                    cl.sendText(msg.to,song[4])
                    print ("[Command] Lagu")

            elif "/lagu " in msg.text:
                songname = msg.text.replace("/lagu ","")
                params = {"songname":songname}
                r = requests.get('https://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    cl.sendText(msg.to,"Judul : " + song[0] + "\nDurasi : " + song[1])
                    cl.sendAudioWithURL(msg.to,song[3])
                    print ("[Command] Lagu")

#----------------------------------------------------------------------------
            elif "En: " in msg.text:
                txt = msg.text.replace("En: ","")
                try:
                    gs = goslate.Goslate()
                    trs = gs.translate(txt,'en')
                    cl.sendText(msg.to,trs)
                    print ('[Command] Translate EN')
                except:
                    cl.sendText(msg.to,'Error.')

            elif "Ein: " in msg.text:
                txt = msg.text.replace("Ein: ","")
                try:
                    gs = goslate.Goslate()
                    trs = gs.translate(txt,'id')
                    cl.sendText(msg.to,trs)
                    print ('[Command] Translate ID')
                except:
                    cl.sendText(msg.to,'Error.')

   	    elif "Vn" in msg.text:
                say = msg.text.replace("Vn","")
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
#--------------------------------- INSTAGRAM --------------------------------
            elif "Ig " in msg.text:
                arg = msg.text.split(' ');
                nk0 = msg.text.replace("/ig ","")
                nk1 = nk0.rstrip('  ')
                if len(arg) > 1:
                    proc = subprocess.Popen('curl -s https://www.instagram.com/'+nk1+'/?__a=1',shell=True, stdout=subprocess.PIPE)
                    x = proc.communicate()[0]
                    parsed_json = json.loads(x)
                    if(len(x) > 10):
                        username = (parsed_json['user']['username'])
                        fullname = (parsed_json['user']['full_name'])
                        followers = (parsed_json['user']['followed_by']['count'])
                        following = (parsed_json['user']['follows']['count'])
                        media = (parsed_json['user']['media']['count'])
                        bio = (parsed_json['user']['biography'])
                        url = (parsed_json['user']['external_url'])
                        cl.sendText(msg.to,"Profile "+username+"\n\nUsername : "+username+"\nFull Name : "+fullname+"\nFollowers : "+str(followers)+"\nFollowing : "+str(following))
                        print ('[Command] Instagram')
                    else:
                        cl.sendText(msg.to,"Not Found...")
                else:
                    cl.sendText(msg.to,"Contoh /ig hairu.ones")

            elif "Youtube" in msg.text:
                 query = msg.text.replace("Youtube","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'http://www.youtube.com/results'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'http://www.youtube.com' + a['href'] + a['title'])
#-------------------------------------------------------------------
            elif "Cover @" in msg.text:
                if msg.toType == 2:
                  if msg.from_ in admin:
                    cover = msg.text.replace("Cover @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.channel.getHome(target)
                                objId = h["result"]["homeInfo"]["objectId"]
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + target + "&oid=" + objId)
                            except Exception as error:
                                print (error)
                                cl.sendText(msg.to,"Upload image failed.")

            elif "Pp @" in msg.text:
                if msg.toType == 2:
                  if msg.from_ in admin:
                    cover = msg.text.replace("Pp @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
                            except Exception as error:
                                print (error)
                                cl.sendText(msg.to,"Upload image failed.")

#-----------------------------------------------------------------
            elif msg.text in ["Lurk","Lurkpoint"]:
               if wait["lurkingOn"] == True:
                 if msg.toType == 2:
                    cl.sendText(msg.to, "Set lurking point . . .")
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = "@"
                    wait2['setTime'][msg.to] = datetime.today().strftime('%H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    print (wait)
            elif msg.text in ["Lurkers","Lurkcheck"]:
               if wait["lurkingOn"] == True:
                 if msg.toType == 2:
                    print "[SET READING POINT]"
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print (rom)
                                chiya += rom[1] + "\n"

                        cl.sendText(msg.to, "[LURKER LIST]\n%s\n\nThese users have seen at the last lurking point . . .\n\n%s" % (wait2['readMember'][msg.to],setTime[msg.to]))
                        wait["lurkingOn"] = True
                        print "[READING POINT SET]"
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = "@"
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        cl.sendText(msg.to, "Auto set lurking point . . .")
                    else:
                        cl.sendText(msg.to, "Set reading point first.  . .")
#========================================
            elif msg.text in ["Point"]:
                 if msg.toType == 2:
                    cl.sendText(msg.to, "Set reading point . . .")
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = "@"
                    wait2['setTime'][msg.to] = datetime.today().strftime('%H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    print (wait)
            elif msg.text in ["Read"]:
                 if msg.toType == 2:
                    print "[READING SET SIDER]"
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print (rom)
                                chiya += rom[1] + "\n"

                        cl.sendText(msg.to,"╔════════════════╗\n╟    CHACKING SIDER\n╚════════════════╝\n%s\n╚════════════════╝\n╔════════════════╗\n╟   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n╚════════════════╝\n╔════════════════╗\n%s\n╚════════════════╝\n╔════════════════╗\n╟   In the last seen point:\n╟   [%s]\n╚════════════════╝\n" % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                        print "[READING POINT SET]"
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = "@"
                        wait2['setTime'][msg.to] = datetime.today().strftime('%H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        cl.sendText(msg.to, "Auto set reading point . . .")
                    else:
                        cl.sendText(msg.to, "Set reading point first . . .")
#-----------------------------------------------
            elif msg.text in ["waktu"]:
                cl.sendText(msg.to, "Current time is\n" + datetime.today().strftime('🕛%M:%M %S'))

            elif msg.text in ["Time",""]:
                timeNow = datetime.now()
                timeHours = datetime.strftime(timeNow,"(%H:%M)")
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                inihari = datetime.today()
                hr = inihari.strftime('%A')
                bulan = inihari.strftime('%m')
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bulan == str(k): bulan = bulan[k-1]
                rst = hasil + ", " + inihari.strftime('%d') + " - " + bulan + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                cl.sendText(msg.to, rst)
#---------------------------------------------------------
            elif msg.text in ["Mentionall","Mytag","Tag"]:
                 group = cl.getGroup(msg.to)
                 nama = [contact.mid for contact in group.members]
                 nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                 if jml <= 100:
                    summon(msg.to, nama)
                 if jml > 100 and jml < 200:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, len(nama)-1):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                 if jml > 200  and jml < 500:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, 299):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                    for l in range(300, 399):
                        nm4 += [nama[l]]
                    summon(msg.to, nm4)
                    for m in range(400, len(nama)-1):
                        nm5 += [nama[m]]
                    summon(msg.to, nm5)
                 if jml > 500:
                     print "Terlalu Banyak Men 500+"
                 cnt = Message()
                 cnt.text = "Jumlah:\n" + str(jml) +  " Members"
                 cnt.to = msg.to
                 cl.sendMessage(cnt)
#========================================
            elif msg.text in ["Masuk","Kicker","Neo join","All join"]:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k3.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k4.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k5.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k6.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k7.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k8.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k9.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        k10.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        k10.updateGroup(G)
                        print "KICKER READY JOIN"
                        G.preventJoinByTicket(G)
                        k10.updateGroup(G)
            elif msg.text in ["A"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k1.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k1.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k1.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k1.reissueGroupTicket(msg.to)
            elif msg.text in ["B"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k2.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k2.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k2.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k2.reissueGroupTicket(msg.to)
            elif msg.text in ["C"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k3.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k3.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k3.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k3.reissueGroupTicket(msg.to)
            elif msg.text in ["D"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k4.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k4.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k4.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k4.reissueGroupTicket(msg.to)
            elif msg.text in ["E"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k5.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k5.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k5.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k5.reissueGroupTicket(msg.to)
            elif msg.text in ["F"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k6.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k6.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k6.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k6.reissueGroupTicket(msg.to)
            elif msg.text in ["G"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k7.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k7.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k7.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k7.reissueGroupTicket(msg.to)
            elif msg.text in ["H"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k8.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k8.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k8.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k8.reissueGroupTicket(msg.to)
            elif msg.text in ["I"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k9.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k9.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k9.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k9.reissueGroupTicket(msg.to)
            elif msg.text in ["J"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k10.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = k10.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  k10.updateGroup(G)
                  print "[KICKER JOINING GROUP]"
                  Ticket = k10.reissueGroupTicket(msg.to)
            elif msg.text in ["Algojo join"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  k10.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = siri.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  siri.updateGroup(G)
                  print "[ALGOJO_QR_JOINING_GROUP]"
                  Ticket = siri.reissueGroupTicket(msg.to)
            elif msg.text in ["Bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k1.leaveGroup(msg.to)
                    k2.leaveGroup(msg.to)
                    k3.leaveGroup(msg.to)
                    k4.leaveGroup(msg.to)
                    k5.leaveGroup(msg.to)
                    k6.leaveGroup(msg.to)
                    k7.leaveGroup(msg.to)
                    k8.leaveGroup(msg.to)
                    k9.leaveGroup(msg.to)
                    k10.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["A bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k1.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["B bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k2.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["C bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k3.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["D bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k4.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["E bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k5.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["F bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k6.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["G bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k7.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["H bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k8.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["I bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k9.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["J bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    k10.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["Algojo bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    siri.leaveGroup(msg.to)
                except:
                    pass

            elif msg.text in ["Bye me","Bye bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    cl.leaveGroup(msg.to)
                except:
                    pass

            elif 'talkban ' in msg.text.lower():
                spl = msg.text.lower().replace('talkban ','')
                if spl == 'on':
                    if wait['talkban'] == True:
                        msgs="Talkban already Not For chat"
                    else:
                        msgs="Talkban set to Not For chat"
                        wait['talkban']=True
                    cl.sendText(msg.to, msgs)
                elif spl == 'off':
                    if wait['talkban'] == False:
                        msgs="Talkban already Allow For chat"
                    else:
                        msgs="Talkban set to Allow For chat"
                        wait['talkban']=False
                    cl.sendText(msg.to, msgs)

            elif "Talkban" in msg.text:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        wait["talkblacklist"][target] = True
                        group = cl.getContact(target)
                        cl.sendText(msg.to,group.displayName + " Succes Add to Talckban.")
                    except:
                        cl.sendText(msg.to,"Error")
            
            elif "Untalk" in msg.text:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        del wait["talkblacklist"][target]
                        group = cl.getContact(target)
                        cl.sendText(msg.to,group.displayName + " Deleted from talkban.")
                    except:
                        cl.sendText(msg.to,group.displayName + " Not in talkban")

#---------------------------------------
            elif "Mk:" in msg.text:
                  if msg.from_ in admin:
                       mk0 = msg.text.replace("Mk:","")
                       mk1 = mk0.lstrip()
                       mk2 = mk1.replace("@","")
                       mk3 = mk2.rstrip()
                       _name = mk3
                       gs = random.choice(KAC).getGroup(msg.to)
                       targets = []
                       for h in gs.members:
                           if _name in h.displayName:
                              targets.append(h.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist . . .")
                           pass
                       else:
                           for target in targets:
                               try:
                                 if msg.from_ not in target:
                                   random.choice(KAC).kickoutFromGroup(msg.to,[target])
                               except:
                                   pass
#==========================================
            elif msg.text in ["Kill"]:
                if msg.toType == 2:
                    klist=[k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                    kicker = random.choice(klist)
                    group = kicker.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        k1.sendText(msg.to,"Fuck You")
                        k2.sendText(msg.to,"Fuck You")
                        return
                    for jj in matched_list:
                        try:
                            random.choice(KAC2).kickoutFromGroup(msg.to,[jj])
                            print (msg.to,[jj])
                        except:
                            pass
            elif "Cleanse" in msg.text:
                if msg.toType == 2:
                    print "[GROUP CLEANSE]"
                    _name = msg.text.replace("Cleanse","")
                    gs = k1.getGroup(msg.to)
                    gs = k2.getGroup(msg.to)
                    gs = k3.getGroup(msg.to)
                    gs = k4.getGroup(msg.to)
                    gs = k5.getGroup(msg.to)
                    gs = k6.getGroup(msg.to)
                    gs = k7.getGroup(msg.to)
                    gs = k8.getGroup(msg.to)
                    gs = k9.getGroup(msg.to)
                    gs = k10.getGroup(msg.to)
                    cl.sendText(msg.to,"􂀁􀄃explosion􏿿 Just some casual cleansing 􂀁􀄃explosion􏿿")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found.")
                    else:
                        for target in targets:
                          if not target in Bots:
                            try:
                               random.choice(KAC).kickoutFromGroup(msg.to,[target])
                               print (msg.to,[g.mid])
                            except:
                                pass

            elif ("Mayhem" in msg.text):
                if msg.toType == 2:
                    print "[GROUP CleanAll]"
                    _name = msg.text.replace("Mayhem","")
                    gs = k1.getGroup(msg.to)
                    gs = k2.getGroup(msg.to)
                    gs = k3.getGroup(msg.to)
                    gs = k4.getGroup(msg.to)
                    gs = k5.getGroup(msg.to)
                    gs = k6.getGroup(msg.to)
                    gs = k7.getGroup(msg.to)
                    gs = k8.getGroup(msg.to)
                    gs = k9.getGroup(msg.to)
                    gs = k10.getGroup(msg.to)
                    k1.sendText(msg.to,"􂀁􀄃explosion  KILLING ALL MEMBER 􂀁􀄃explosion􏿿")
                    k2.sendText(msg.to," Mayhem . . .\n Mayhem is STARTING♪\n 'abort' to abort♪")
                    k3.sendText(msg.to," Mayhem . . .\n 46 victims shall yell hul·la·ba·loo♪\n /ˌhələbəˈlo͞o,ˈhələbəˌlo͞o/")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found.")
                    else:
                        for target in targets:
                          if not target in Bots:
                            try:
                                kicker = random.choice(KAC)
                                kicker.kickoutFromGroup(msg.to,[target])
                                print (msg.to,[g.mid])
                            except:
                                pass

            elif ("Nk" in msg.text):
              if msg.from_ in admin:
                 if msg.toType == 2:
                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                        	if msg.from_ not in target:
                        		random.choice(KAC2).kickoutFromGroup(msg.to,[target])
                        		print (msg.to,[g.mid])
                        except:
                        	cl.sendText(msg,to, " Good bye . . . SORRY . . .")

            elif ("Fuck" in msg.text):
              if msg.from_ in admin:
                 if msg.toType == 2:
                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                        	if msg.from_ not in target:
                        		cl.kickoutFromGroup(msg.to,[target])
                        		print (msg.to,[g.mid])
                        except:
                        	cl.sendText(msg,to, " Good bye . . . SORRY . . .")

            elif "Kick" in msg.text:
              if msg.from_ in admin:
                 if msg.toType == 2:
                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                        	if msg.from_ not in target:
                        		cl.kickoutFromGroup(msg.to,[target])
                        		print (msg.to,[g.mid])
                        except:
                        	cl.sendText(msg,to, " Good bye . . . SORRY . . .")

            elif "Tkick" in msg.text:
                if msg.toType == 2:
                     print "[Kick on]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                        try:
                        	if msg.from_ not in target:
                        		cl.kickoutFromGroup(msg.to,[target])
                        		print (msg.to,[g.mid])
                        except:
                        	cl.sendText(msg,to, " Good bye . . . SORRY . . .")
#----------------------------------------------------------------
            elif "Neo1 kick" in msg.text:
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           k1.kickoutFromGroup(msg.to,[target])
                       except:
                           k1.sendText(msg.to,"Error")
            elif ("Neo2 kick" in msg.text):
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           k2.kickoutFromGroup(msg.to,[target])
                       except:
                           k2.sendText(msg.to,"Error")
            elif "Neo3 kick" in msg.text:
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           k3.kickoutFromGroup(msg.to,[target])
                       except:
                           k3.sendText(msg.to,"Error")

#-----------------------------------------------------------------
            elif msg.text in ["Mimic on","mimic on"]:
                    if wait3["copy"] == True:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Already on")
                        else:
                            cl.sendText(msg.to,"Mimic On")
                    else:
                    	wait3["copy"] = True
                    	if wait["lang"] == "JP":
                    	    cl.sendText(msg.to,"Mimic On")
                    	else:
    	                	cl.sendText(msg.to,"Already on")
            elif msg.text in ["Mimic off","mimic:off"]:
                    if wait3["copy"] == False:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Already on")
                        else:
                            cl.sendText(msg.to,"Mimic Off")
                    else:
                    	wait3["copy"] = False
                    	if wait["lang"] == "JP":
                    	    cl.sendText(msg.to,"Mimic Off")
                    	else:
	                    	cl.sendText(msg.to,"Already on")
            elif msg.text in ["Target list"]:
                        if wait3["target"] == {}:
                            cl.sendText(msg.to,"nothing")
                        else:
                            mc = "Target mimic user\n"
                            for mi_d in wait3["target"]:
                                mc += "✔️ "+cl.getContact(mi_d).displayName + "\n"
                            cl.sendText(msg.to,mc)

            elif "Mimic target " in msg.text:
                        if wait3["copy"] == True:
                            siapa = msg.text.replace("Mimic target ","")
                            if siapa.rstrip(' ') == "me":
                                wait3["copy2"] = "me"
                                cl.sendText(msg.to,"Mimic change to me")
                            elif siapa.rstrip(' ') == "target":
                                wait3["copy2"] = "target"
                                cl.sendText(msg.to,"Mimic change to target")
                            else:
                                cl.sendText(msg.to,"I dont know")
            elif "Target @" in msg.text:
                        target = msg.text.replace("Target @","")
                        gc = cl.getGroup(msg.to)
                        targets = []
                        for member in gc.members:
                            if member.displayName == target.rstrip(' '):
                                targets.append(member.mid)
                        if targets == []:
                            cl.sendText(msg.to, "User not found")
                        else:
                            for t in targets:
                                wait3["target"][t] = True
                            cl.sendText(msg.to,"Target added")
            elif "Del target @" in msg.text:
                        target = msg.text.replace("Del target @","")
                        gc = cl.getGroup(msg.to)
                        targets = []
                        for member in gc.members:
                            if member.displayName == target.rstrip(' '):
                                targets.append(member.mid)
                        if targets == []:
                            cl.sendText(msg.to, "User not found")
                        else:
                            for t in targets:
                                del wait3["target"][t]
                            cl.sendText(msg.to,"Target deleted")
#====================================================================
            elif msg.text in ["Quote"]:
            	quote = ['Good friends are like stars you dont always see them but they are always there\n\nQuotes by NEO','dreams are like stars you may never catch them but if you follow them they will lead you to your destiny\n\nQuotes by NEO','jangan pernah lupain temen terbaik karna teman terbaik tidak datang 2 kali tolong ingat keseruan keseruan kita dulu\n\nQuotes by NEO']
            	psn = random.choice(quote)
            	cl.sendText(msg.to,psn)
            elif msg.text in ["Pagi","Morning","pagi","morning"]:
                pagi = ['Selamat pagi semua selamat beraktivitas ya\n','Pagi jangan lupa sarapan ya karna pura pura bahagia juga butuh energi\n','Pagi pagi enaknya ngupi sambil stalking stalking mantan\n']
                psn = random.choice(pagi)
                cl.sendText(msg.to,psn)

            elif ".quotes" in msg.text:
                tanya = msg.text.replace(".quotes","")
                jawab = ("Manusia hendaknya mulai dari detik ini juga mengusahakan dengan tidak pernah jemu untuk memahami hakekat Kebajikan/kebenaran, Kekayaan, Kesenangan, dan Kebebasan. Manusia adalah Sang Raja bagi dirinya sendiri, ia adalah pemimpin dari tubuhnya, ia adalah penguasa dari pikirannya; maka dari itu, berusahalah untuk memahami hakekat penjelmaan ini","Janganlah pernah bersedih hati dilahirkan menjadi manusia, meskipun pada kelahiran yang dianggap paling hina; karena sesungguhnya amat sulit untuk bisa menjelma menjadi manusia. Berbahagialah menjadi manusia","Mereka yang telah melakukan kebajikan pun kebenaran, namun masih terikat dalam proses lahir dan mati, mereka ini belumlah memperoleh inti sari dari kebebasan","Kebajikan dan kebenaran itu laksana perahu yang dapat mengantarkan manusia untuk pergi ke surga","Mustahil ada persahabatan tanpa kesabaran hati, yang ada pastilah kemurkaan, marah dan dendam, maka dari itu pupuklah terus kesabaran di dalam hati masing-masing")
                jawaban = random.choice(jawab)
                cl.sendText(msg.to,jawaban)

            elif "/say-id " in msg.text:
                say = msg.text.replace("/say-id ","")
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
#-------------------------------------------------
            elif "/say-en " in msg.text:
                say = msg.text.replace("/say-en ","")
                lang = 'en'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
#------------------------------------------------

            elif "Ban:on" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            wait ["blacklist"][target] = True
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"ヽ( ^ω^)ﾉ Success add blacklist . . .")
                        except:
                           pass
            elif "Unban:on" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del wait ["blacklist"][target]
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"ヽ( ^ω^)ﾉ Success add to blacklist . . .")
                        except:
                           pass
#            elif ("Block" in msg.text):
#                 if msg.toType == 2:
#                     targets = []
#                     key = eval(msg.contentMetadata["MENTION"])
#                     key["MENTIONEES"][0]["M"]
#                     for x in key["MENTIONEES"]:
#                         targets.append(x["M"])
#                     for target in targets:
#                         try:
#                            cl.blockContact(target)
#                            cl.sendText(msg.to, "Success block contact . . .")
#                         except Exception as e:
#                            print e

            elif msg.text in ["Conban","Cbanlist","Contact ban"]:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Nothing  Blacklist user . . .")
                else:
                    cl.sendText(msg.to,"Daftar Contact banlist . . .")
                    h = ""
                    for i in wait["blacklist"]:
                        h = cl.getContact(i)
                        M = Message()
                        M.to = msg.to
                        M.contentType = 13
                        M.contentMetadata = {'mid': i}
                        cl.sendMessage(M)

            elif msg.text in ['Blocklist']:
                blockedlist = cl.getBlockedContactIds()
                cl.sendText(msg.to, "Please wait...")
                kontak = cl.getContacts(blockedlist)
                num=1
                msgs="[User Blocked List]\n"
                for ids in kontak:
                    msgs+="\n%i. %s" % (num, ids.displayName)
                    num=(num+1)
                msgs+="\n\nTotal %i blocked user(s)" % len(kontak)
                cl.sendText(msg.to, msgs)

            elif msg.text in ["Clear ban","Unbanall","Clear banlist"]:
                wait["blacklist"] = {}
                cl.sendText(msg.to,"☑ Blacklist ready Cleared ☺ . . .")
            elif msg.text in ["Ban"]:
                wait["wblacklist"] = True
                cl.sendText(msg.to,"send contact to blacklist . . .")
            elif msg.text in ["Unban"]:
                wait["dblacklist"] = True
                cl.sendText(msg.to,"send contact to whitelist . . .")
            elif msg.text in ["Ban on repeat","Ban:repeat"]:
                wait["rblacklist"] = True
                cl.sendText(msg.to,"Send Contact to Banned . . .")
            elif msg.text in ["Unban on repeat","Unban:repeat"]:
                wait["rdblacklist"] = True
                cl.sendText(msg.to,"Send Contact to Unbanned . . .")
            elif msg.text in ["Repeat:off","Repeat off"]:
                wait["rblacklist"] = False
                wait["rdblacklist"] = False
                cl.sendText(msg.to,"Turn off repeat . . .")
            elif msg.text in ["Banlist"]:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Nothing banlist user . . .")
                else:
                    cl.sendText(msg.to,"Waiting . . . .!!!!\nChacking blacklist user . . . .")
                    num=1
                    mc = "User Blacklist\n"
                    for mi_d in wait["blacklist"]:
                        mc += "%i. %s\n" % (num, cl.getContact(mi_d).displayName)
                        num=(num+1)
                    cl.sendText(msg.to, mc + "" + "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

            elif msg.text in ["Ban cek","Cekban","Bl check"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = "User Blacklist"
                    for mm in matched_list:
                        cocoa += "\n" + mm + "\n"
                    cl.sendText(msg.to, cocoa + "" +  "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")

            elif msg.text in ["Kill ban"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"There was no blacklist user . . .")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                        k1.kickoutFromGroup(msg.to,[jj])
                        k2.kickoutFromGroup(msg.to,[jj])
                        k3.kickoutFromGroup(msg.to,[jj])
                        k4.kickoutFromGroup(msg.to,[jj])
                        k5.kickoutFromGroup(msg.to,[jj])
                        k6.kickoutFromGroup(msg.to,[jj])
                        k7.kickoutFromGroup(msg.to,[jj])
                        k8.kickoutFromGroup(msg.to,[jj])
                        k9.kickoutFromGroup(msg.to,[jj])
                        k10.kickoutFromGroup(msg.to,[jj])
                        cl.sendText(msg.to,"Refusing blacklist user . . .")
                        k2.sendText(msg.to, "Done refusing blacklist in groups . . .")

            elif msg.text in ["Ban mid","banlistmid"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = "[⎈] Mid Banlist [⎈]"
                    for mm in matched_list:
                        cocoa += "\n" + mm + "\n"
                    cl.sendText(msg.to,cocoa + "")

#-----------------------------------------------
            elif msg.text in ["Stest","Sp","Speed"]:
                start = time.time()
                cl.sendText(msg.to, "Waiting speed progresss...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
            elif msg.text in ["Allspeed"]:
                if msg.toType == 2:
                   start = time.time()
                   cl.sendText(msg.to, "Progress...")
                   elapsed_time = time.time() - start
                   random.choice(KAC).sendText(msg.to, "%sseconds" % (elapsed_time))

            elif ("Cek" in msg.text):
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getContact(key1)
                   cl.sendText(msg.to,"[Mid]    \n\n" +  key1)

#-----------------------------------------------
            elif msg.text in ["Restart"]:
                 cl.sendText(msg.to, "Succes Restarted")
                 restart_program()
                 print ("[RESTART PROGRAM]")

            elif msg.text.lower() == 'runtime':
                eltime = time.time() -start
                van = "Bot sudah berjalan selama "+waktu(eltime)
                cl.sendText(msg.to,van)
#----------------------------------------------

            elif "Getname @" in msg.text:
                 _name = msg.text.replace("Getname @","")
                 _nametarget = _name.rstrip(" ")
                 gs = cl.getGroup(msg.to)
                 for h in gs.members:
                   if _nametarget == h.displayName:
                      cl.sendText(msg.to,"[DisplayName]:\n" + h.displayName )
                   else:
                     pass
            elif "Getinfo" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                    cl.sendImageWithUrl(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName)
                    cl.sendImageWithUrl(msg.to,path)
                except:
                    pass
            elif "Getbio @" in msg.text:
                 _name = msg.text.replace("Getbio @","")
                 _nametarget = _name.rstrip(" ")
                 gs = cl.getGroup(msg.to)
                 gs = cl.getProfile(msg.to)
                 for h in gs.members:
                   if _nametarget == h.displayName:
                      cl.sendText(msg.to,"[StatusMessage]:\n" + h.statusMessage)                 
                   else:
                     pass

            elif "Say-id: " in msg.text:
                    say = msg.text.replace("Say-id: ","")
                    lang = 'id'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")

            elif "Say-ja: " in msg.text:
                    say = msg.text.replace("Say-ja: ","")
                    lang = 'ja'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(msg.to,"hasil.mp3")

            elif "Say-en: " in msg.text:
                    say = msg.text.replace("Say-en: ","")
                    lang = 'en'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(msg.to,"hasil.mp3")
 
#---------------------------------------------------------------#
            elif "Mid @" in msg.text:
            	if msg.from_ in admin:
                  _name = msg.text.replace("Mid @","")
                  _nametarget = _name.rstrip(' ')
                  gs = cl.getGroup(msg.to)
                  for g in gs.members:
                      if _nametarget == g.displayName:
                          cl.sendText(msg.to, g.mid)
                      else:
                          pass

            elif 'music ' in msg.text.lower():
                cl.sendText(msg.to,"Tunggu...")
                try:
                    songname = msg.text.lower().replace('music ','')
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Ini Dia Hasilnya\n'
                        hasil += 'Judul : ' + song[0]
                        hasil += '\nDurasi : ' + song[1]
                        hasil += '\nLink Download : ' + song[4]
                        cl.sendText(msg.to, hasil)
                        cl.sendText(msg.to, "Tunggu VN Musiknya...")
                        cl.sendAudioWithURL(msg.to, song[4])
                except Exception as njer:
                    cl.sendText(msg.to, str(njer))
            
            elif ".Youtube " in msg.text:
                 query = msg.text.replace(".Youtube ","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url    = 'http://www.youtube.com/results'
                     params = {'search_query': query}
                     r    = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'http://www.youtube.com' + a['href'] + a['title'])

#-----------------------------------------------

            if wait["akaInvite"] == True:
                     if msg.from_ in admin:
                         _name = msg.contentMetadata["displayName"]
                         invite = msg.contentMetadata["mid"]
                         groups = cl.getGroup(msg.to)
                         pending = groups.invitee
                         targets = []
                         for s in groups.members:
                             if _name in s.displayName:
                                 k1.sendText(msg.to,"-> " + _name + " was here")
                                 break
                             elif invite in wait["blacklist"]:
                                 k2.sendText(msg.to,"Sorry, " + _name + " On Blacklist user")
                                 k3.sendText(msg.to,"Call my daddy to use command !, \n➡ Unban: " + invite)
                                 wait["akaInvite"] = True
                                 break
                             else:
                                 targets.append(invite)
                         if targets == []:
                             pass
                         else:
                             for target in targets:
                                 try:
                                     cl.findAndAddContactsByMid(target)
                                     cl.inviteIntoGroup(msg.to, [target])
                                     k1.sendText(msg.to," Invited: \n➡ " + _name)
                                     wait["akaInvite"] = False
                                     break
                                 except:
                                        k1.sendText(msg.to,"Negative, Err0r Detected")
                                        wait["akaInvite"] = False
                                        break


        if op.type == 55:
          if wait["lurkingOn"] == True:
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n✑ " + Name + datetime.today().strftime(' [ %H:%M:%S]')
                        wait2['ROM'][op.param1][op.param2] = "✑ " + Name
                        wait2['setTime'][msg.to] = datetime.today().strftime(' %H:%M:%S')
                else:
                    pass
            except:
                pass

        if op.type == 26:
            msg = op.message
            try:
                if msg.contentType == 0:
                    try:
                        if msg.to in wait2['readPoint']:
                            if msg.from_ in wait2["ROM"][msg.to]:
                                del wait2["ROM"][msg.to][msg.from_]
                        else:
                            pass
                    except:
                        pass
                else:
                    pass

            except KeyboardInterrupt:
                sys.exit(0)
            except Exception as error:
                print (error)
                print ("\n\nRECEIVE_MESSAGE\n\n")
                return

            if cms(msg.text,["Lurkers"]):
              if wait["lurkingOn"] == True:
                 if msg.toType == 2:
                    print ("\nSider check aktif...")
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print (rom)
                                chiya += rom[1] + "\n"

                        k1.sendText(msg.to, "[LURKER LIST]\n%s\n\nThese users have seen at the last lurking point . . .\n\n%s" % (wait2['readMember'][msg.to],setTime[msg.to]))
                        wait["lurkingOn"] = True
                        print ("\nReading Point Set...")
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        k1.sendText(msg.to, "Auto set lurking point . . .\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                    else:
                        wait["lurkingOn"] = True
                        k1.sendText(msg.to, "Wait for set lurking point...\n\n ➡List time : " + datetime.today().strftime('%H:%M:%S'))
                        print ("\nReading Point Set...")
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print (wait)
                        k1.sendText(msg.to, "Lurking ready to check list\nSend「#lurkers」again")
                 else:
                     k1.sendText(msg.to, "Error..")
#---------------------------------------------------------------------------
            if cms(msg.text,["Setlastpoint"]):
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
                print "[SETLASTPOINT]"
            if cms(msg.text,["Viewlastseen"]):
                lurkGroup = ""
                dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
                with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%d日 %H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        grp = '\n• '.join(str(f) for f in dataResult)
                        total = '\n\nThese %i\n\n----------------------------------\nuesrs have seen at the lastseen\npoint(｀・ω・´)\n\n%s' % (len(dataResult), datetime.now().strftime('%H:%M:%S') )
                        cl.sendText(msg.to, "• %s %s" % (grp, total))
                    else:
                        cl.sendText(msg.to, "Sider ga bisa di read cek setpoint dulu  ketik\nSetlastpoint\nkalo mau liat sider ketik\nViewlastseen")
                    print "[VIEWLASTSEEN]"
#----------------------------------------------------------------------
            if cms(msg.text,["Tagall"]):
                 group = cl.getGroup(msg.to)
                 nama = [contact.mid for contact in group.members]
                 nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                 if jml <= 100:
                    summon(msg.to, nama)
                 if jml > 100 and jml < 200:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, len(nama)-1):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                 if jml > 200  and jml < 500:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, 299):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                    for l in range(300, 399):
                        nm4 += [nama[l]]
                    summon(msg.to, nm4)
                    for m in range(400, len(nama)-1):
                        nm5 += [nama[m]]
                    summon(msg.to, nm5)
                 if jml > 500:
                     print "Terlalu Banyak Men 500+"
                 cnt = Message()
                 cnt.text = "Jumlah:\n" + str(jml) +  " Members"
                 cnt.to = msg.to
                 cl.sendMessage(cnt)
#----------------------------------------------------------------------
            if cms(msg.text,["Ban:on"]):
                if msg.toType == 2:
                    if msg.from_ in admin:
                        wait["wblacklist"] = True
                        random.choice(KAC2).sendText(msg.to,"Send Contact to Banned . . .")

            if cms(msg.text,["Unban:on"]):
                if msg.toType == 2:
                    if msg.from_ in admin:
                        wait["dblacklist"] = True
                        random.choice(KAC2).sendText(msg.to,"Send Contact to Unbanned . . .")

            if cms(msg.text,["Banlist"]):
            	if msg.from_ in admin:
            		if wait["blacklist"] == {}:
            			cl.sendText(msg.to,"Nothing banlist user . . .")
            		else:
            			cl.sendText(msg.to,"Waiting . . . .!!!!\nChacking blacklist user . . .")
            			num=1
            			mc = "[USER IN BLACKLIST]\n\n"
            			for mi_d in wait["blacklist"]:
            				mc += "%i. %s\n" % (num, cl.getContact(mi_d).displayName)
            				num=(num+1)
            				cl.sendText(msg.to, mc + "" + "\nDETIME: " + datetime.today().strftime(' [%d - %H:%M:%S]') + "\n༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ ")
#----------------------------------------------------------------------
            if cms(msg.text,["Group creator"]):
              if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)
#----------------------------------------------------------------------
            if cms(msg.text,["Selamat pagi"]):
                pagi = ['Selamat pagi semua selamat beraktivitas ya\n','Pagi jangan lupa sarapan ya karna pura pura bahagia juga butuh energi\n','Pagi pagi enaknya ngupi sambil stalking stalking mantan\n']
                psn = random.choice(pagi)
                cl.sendText(msg.to,psn)

            if cms(msg.text,["Foto","Cekrek"]):
            	if msg.from_ in admin:
            		cl.sendImageWithURL(msg.to, "https://images.google.co.id/imgres?imgurl=https%3A%2F%2F3.bp.blogspot.com%2F-VjvtpFc4mak%2FVz_WuJ_x3uI%2FAAAAAAAAAEI%2FXY9UICe817094VN-vezO7jUhKsRrEHU3wCLcB%2Fs1600%2Fhqdefault.jpg&imgrefurl=http%3A%2F%2Fmbahbeni.blogspot.com%2F2016%2F05%2Fhantu-mata-besar-di-bawah-pohon-besar.html&docid=0eICNlm6uAAzbM&tbnid=VXtPSCgJseqC0M%3A&vet=1&w=480&h=360&source=sh%2Fx%2Fim")

            if cms(msg.text,["Quotes"]):
                tanya = msg.text.replace("Quotes","")
                jawab = ("Manusia hendaknya mulai dari detik ini juga mengusahakan dengan tidak pernah jemu untuk memahami hakekat Kebajikan/kebenaran, Kekayaan, Kesenangan, dan Kebebasan. Manusia adalah Sang Raja bagi dirinya sendiri, ia adalah pemimpin dari tubuhnya, ia adalah penguasa dari pikirannya; maka dari itu, berusahalah untuk memahami hakekat penjelmaan ini","Janganlah pernah bersedih hati dilahirkan menjadi manusia, meskipun pada kelahiran yang dianggap paling hina; karena sesungguhnya amat sulit untuk bisa menjelma menjadi manusia. Berbahagialah menjadi manusia","Mereka yang telah melakukan kebajikan pun kebenaran, namun masih terikat dalam proses lahir dan mati, mereka ini belumlah memperoleh inti sari dari kebebasan","Kebajikan dan kebenaran itu laksana perahu yang dapat mengantarkan manusia untuk pergi ke surga","Mustahil ada persahabatan tanpa kesabaran hati, yang ada pastilah kemurkaan, marah dan dendam, maka dari itu pupuklah terus kesabaran di dalam hati masing-masing")
                jawaban = random.choice(jawab)
                cl.sendText(msg.to,jawaban)

            if cms(msg.text,["Respon","Responsename"]):
                s0 = cl.getProfile()
                cl.sendText(msg.to, s0.displayName)
                s1 = k1.getProfile()
                k1.sendText(msg.to, s1.displayName)
                s2 = k2.getProfile()
                k2.sendText(msg.to, s2.displayName)
                s3 = k3.getProfile()
                k3.sendText(msg.to, s3.displayName)
                s4 = k4.getProfile()
                k4.sendText(msg.to, s4.displayName)
                s5 = k5.getProfile()
                k5.sendText(msg.to, s5.displayName)
                s6 = k6.getProfile()
                k6.sendText(msg.to, s6.displayName)
                s7 = k7.getProfile()
                k7.sendText(msg.to, s7.displayName)
                s8 = k8.getProfile()
                k8.sendText(msg.to, s8.displayName)
                s9 = k9.getProfile()
                k9.sendText(msg.to, s9.displayName)
                s10 = k10.getProfile()
                k10.sendText(msg.to, s10.displayName)

            if cms(msg.text,["Wkwk"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "100",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Hehe"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "10",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Galon"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "9",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["You"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "7",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Sue"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "105",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["huft"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "104",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Please","Tolong"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "4",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Haaa"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "3",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Lol"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "110",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Hmmm","Hemmb"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "101",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
            if cms(msg.text,["Wc","Kam"]):
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "247",
                                     "STKPKGID": "3",
                                     "STKVER": "100" }
                k1.sendMessage(msg)
                k2.sendMessage(msg)
                k3.sendMessage(msg)
                k4.sendMessage(msg)
                k5.sendMessage(msg)
                k6.sendMessage(msg)
                k7.sendMessage(msg)
                k8.sendMessage(msg)
                k9.sendMessage(msg)
#---------------------------------------------------------------------------------
            elif cms(msg.text,["Chatbot:on"]):
            	if msg.from_ in admin:
            		settings["chatbot"][msg.to] = True
            		cl.sendText(msg.to,"Success activated Auto Chat Bot . . .")
            elif cms(msg.text,["Chatbot:off"]):
            	if msg.from_ in admin:
            		settings["chatbot"][msg.to] = False
            		cl.sendText(msg.to,"Success deactived Auto Chat Bot . . .")
#----------------------------------------------------------------------
#----------------------------------------------------------------------
#======================================================================
            elif cms(msg.text,["Settings"]):
            	print "[SETTINGS CHECK SET]"
                md = "⊷ PROTECT SETTINGS BOTS\n--------------------------------\n"
                if wait["Backup"] == True: md+="⋟ Backup : on\n"
                else:md+="⋟ Backup : off\n"
                if wait["protectCancel"] == True: md+="⋟ Protect invite : on\n"
                else:md+="⋟ Protect invite : off\n"
                if wait["blockInviteOn"] == True: md+="⋟ Block invite : on\n"
                else:md+="⋟ Block invite : off\n"
                if wait["pname"] == True: md+="⋟  Protect name : on\n"
                else:md+="⋟ Protect name : off\n"
                if wait["qr"] == True: md+="⋟ Protect Link : on\n"
                else:md+="⋟ Protect Link : off\n"
                if wait["protectionOn"] == True: md+="⋟ Protection : on\n"
                else:md+="⋟ Protection : off\n"
                if wait["atjointicket"] == True: md+="⋟ Chatbot : on\n--------------------------------\n⊶AUTHOR BOT BY NEO\n⊷༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"+ datetime.today().strftime(' [%H:%M:%S]')
                else:md+="⋟ Chatbot :: off\n---------------------------------\n⊶ AUTHOT BOT BY NEO\n⊷༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\nDETIME TODAY :"+ datetime.today().strftime(' [%H:%M:%S]')
                k1.sendText(msg.to,md)
#=======================================================================

            elif cms(msg.text,["Neo backup:on"]):
            	if msg.from_ in admin:
            		if wait["Backup"] == True:
            			if wait["lang"] == "JP":
            				k1.sendText(msg.to,"Backuping member is already on . . .")
            			else:
            				k1.sendText(msg.to,"Backup is turned On . . .")
            		else:
            			wait["Backup"] = True
            			if wait["lang"] == "JP":
            				k1.sendText(msg.to,"Backup is turned On . . .")
            			else:
            				k1.sendText(msg.to,"Backuping member is lready on . . .")
            elif cms(msg.text,["Neo backup:off"]):
            	if msg.from_ in admin:
            		if wait["Backup"] == False:
            			if wait["lang"] == "JP":
            				k10.sendText(msg.to,"Backups already swiching  off . . .")
            			else:
            				k10.sendText(msg.to,"Backup is turned Off . . .")
            		else:
            			wait["Backup"] = False
            			if wait["lang"] == "JP":
            				k10.sendText(msg.to,"Backup is turned Off . . .")
            			else:
            				k10.sendText(msg.to,"Backups is already swiching off . . .")
            elif cms(msg.text,["Neo invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    cl.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text, ["Neo invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    cl.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo1 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k1.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo1 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k1.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo2 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k2.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo2 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k2.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo3 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k3.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo3 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k3.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo4 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k4.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo4 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k4.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo5 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k5.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo5 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k5.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo6 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k6.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo6 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k6.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo7 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k7.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo7 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k7.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo8 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k8.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo8 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k8.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo9 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k9.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo9 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k9.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo10 invite:on"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    k10.sendText(msg.to,"Send a contact to invite . . .")
            elif cms(msg.text,["Neo10 invite:stop"]):
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    k10.sendText(msg.to,"Invite Stoped . . .")
            elif cms(msg.text,["Neo protection:off"]):
            	if msg.from_ in admin:
            		wait["protectionOn"] = False
            		k10.sendText(msg.to,"Turn off Protection . . .")
            elif cms(msg.text, ["Neo protect link:off"]):
            	if msg.from_ in admin:
            		wait["qr"] = False
            		k10.sendText(msg.to,"Turn off link protect . . .")
            elif cms(msg.text,["Neo protect gname:off"]):
            	if msg.from_ in admin:
            		wait["pname"] = False
            		k10.sendText(msg.to,"Turn off group name protect . . .")
            elif cms(msg.text,["Neo protect invite:off"]):
            	if msg.from_ in admin:
            		wait["blockinviteOn"] = False
            		k10.sendText(msg.to,"Turn off invitation protect . . .")
            elif cms(msg.text,["Neo protect cancel:off"]):
            	if msg.from_ in admin:
            		wait["protectCancel"] = False
            		k10.sendText(msg.to,"Turn off cancel invitation  protect . . .")
#---------------------------------------------------------------------
            elif cms(msg.text,["Neo protection:on"]):
            	if msg.from_ in admin:
            		wait["protectionOn"] = True
            		k1.sendText(msg.to,"Protection turn on . . .")
            elif cms(msg.text,["Neo protect link:on"]):
            	if msg.from_ in admin:
            		wait["qr"] = True
            		k1.sendText(msg.to,"Protection link turn on . . .")
            elif cms(msg.text,["Neo protect gname:on"]):
            	if msg.from_ in admin:
            		wait["pname"] = True
            		k1.sendText(msg.to,"Protection group name turn on . . .")
            elif cms(msg.text,["Neo protect invite:on"]):
            	if msg.from_ in admin:
            		wait["blockinviteOn"] = True
            		k1.sendText(msg.to,"Protection invitation turn on . . .")
            elif cms(msg.text,["Neo protect cancel:on"]):
            	if msg.from_ in admin:
            		wait["protectCancel"] = True
            		k1.sendText(msg.to,"Protection cancel invitation turn on . . .")

            elif cms(msg.text,["Bot help"]):
                if msg.toType == 2:
                	print "[HELP PUBLIK COMMANDS]"
                	if wait["lang"] == "JP":
                		neo = [cl,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10]
                		aka = cl.getProfile().displayName
                		random.choice(neo).sendText(msg.to, "[⌛] Author by Neo: \n" + aka )
                		random.choice(neo).sendText(msg.to,"""⊶🔰 Comment Bot Author🔰
⊶ PUBLIK COMMENT
------------------------------------
⊶ LOAD CHAT COMMENT
------------------------------------!
⊶ /Author help
⊶ /Help
⊶ Tagall
⊶ Quotes
⊶ Respon
⊶ Responsename
⊶ Setlastpoint
⊶ Viewlastseen
⊶ Selamat pagi
⊶ Group creator
------------------------------------
⊶ STICKER CHAT ALL BOTS
------------------------------------
⊶ Hehe
⊶ You
⊶ Sue
⊶ Lol
⊶ Wc
⊶ Kam
⊶ Wkwk
⊶ Galon
⊶ Huft
⊶ Please
⊶ Haaa
⊶ Hmmm
-------------------------------------
⊶ STAFF COMMANDS
-------------------------------------
⊶ Ban:on
⊶ Unban:on
⊶ Bot say (txt)
⊶ Ping
⊶ Bot gift
⊶ /Time
⊶ Profile @
⊶ Banlist
⊶ Cek mid @
⊶ Group creator
------------------------------------
⊶ PROTECT BOT AND SETTINGS
------------------------------------
⊶ Settings
⊶ Chatbot:on/off
⊶ Neo backup:on/off
⊶ Neo protection:on/off
⊶ Neo protect link:on/off
⊶ Neo protect invite:on/off
⊶ Neo protect cancel:on/off
⊶ Neo protect gname:on/off
------------------------------------
⊶ AUTHOR BOTS V 0.0.1
⊶ ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n DETIME TODAY :""" + datetime.now().strftime('%H:%M:%S'))
                	else:
                		random.choice(neo).sendText(msg.to, aka)

        if op.type == 55:
            print ("[NOTIFIED_READ_MESSAGE]")
            try:
                if op.param1 in wait2['readPoint']:
                    Nama = cl.getContact(op.param2).displayName
                    if Nama in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "" + Nama
                        wait2['ROM'][op.param1][op.param2] = "" + Nama
                        wait2['setTime'][msg.to] = datetime.today().strftime(' %H:%M:%S')
                else:
                    cl.sendText
            except:
                pass

        if op.type == 59:
            print (op)

    except Exception as error:
        print (error)

def download(url):
    file_name = url.split("/")[-1] + '.jpg'
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36"}) 
    r = urllib.request.urlopen( req )
    i = Image.open(io.BytesIO(r.read()))
    i.save(file_name)
    return file_name

def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
def nameUpdate():
    while True:
        try:
            if wait["clock"] == True:
                now2 = datetime.now()
                nowT = datetime.strftime(now2,"(%H:%M)")
                profile = cl.getProfile()
                profile.displayName = wait["cName"] + nowT
                cl.updateProfile(profile)
            time.sleep(600)
        except:
            pass
thread2 = threading.Thread(target=nameUpdate)
thread2.daemon = True
thread2.start()

while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)
